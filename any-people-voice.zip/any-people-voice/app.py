# -*- coding: utf-8 -*-
"""Any people bd voice clone — CPU/সার্ভার (নোটবুক ছাড়া)। চালান:  python app.py
নোটবুকের একই কোড, একই index.html; শুধু ক্রমানুসারে সাজানো। সার্ভার চালু থাকে Ctrl+C পর্যন্ত।"""
import os
BASE_DIR = os.environ.get("VOICE_LAB_DIR", os.path.expanduser("~/BanglaVoiceLab"))
os.makedirs(f"{BASE_DIR}/models", exist_ok=True); os.makedirs(f"{BASE_DIR}/bin", exist_ok=True)
os.environ["HF_HOME"] = f"{BASE_DIR}/models"   # huggingface import-এর আগেই সেট হতে হবে
CF_BIN = f"{BASE_DIR}/bin/cloudflared"
if os.environ.get("USE_TUNNEL", "1") != "0" and not os.path.exists(CF_BIN):
    import platform, subprocess
    _a = "arm64" if platform.machine().lower() in ("aarch64", "arm64") else "amd64"
    subprocess.Popen(f"wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-{_a} -O {CF_BIN}.part && chmod +x {CF_BIN}.part && mv {CF_BIN}.part {CF_BIN}", shell=True)

# ══════ নোটবুক সেল 3 ══════
#@title Google Drive মাউন্ট (ভয়েস প্রোফাইল স্থায়ীভাবে সেভ করতে)
USE_DRIVE = True  #@param {type:"boolean"}
import os
# CPU/সার্ভারে Google Drive লাগে না: স্থায়ী লোকাল ফোল্ডার ব্যবহার হয় (USE_DRIVE এখানে কোনো প্রভাব ফেলে না)
BASE_DIR = globals().get("BASE_DIR") or os.environ.get("VOICE_LAB_DIR", os.path.expanduser("~/BanglaVoiceLab"))
LIB_DIR = BASE_DIR
WORK_DIR = f"{LIB_DIR}/tmp"
for _d in ("voices", "outputs", "models", "uploads", "tmp"):
    os.makedirs(f"{LIB_DIR}/{_d}", exist_ok=True)
print("লাইব্রেরি:", LIB_DIR)


# ══════ নোটবুক সেল 5 ══════
#@title বাংলা টেক্সট নরমালাইজার
import re, unicodedata

_SMALL = {
    0: 'শূন্য',
    1: 'এক',
    2: 'দুই',
    3: 'তিন',
    4: 'চার',
    5: 'পাঁচ',
    6: 'ছয়',
    7: 'সাত',
    8: 'আট',
    9: 'নয়',
    10: 'দশ',
    11: 'এগারো',
    12: 'বারো',
    13: 'তেরো',
    14: 'চৌদ্দ',
    15: 'পনেরো',
    16: 'ষোলো',
    17: 'সতেরো',
    18: 'আঠারো',
    19: 'উনিশ',
    20: 'বিশ',
    21: 'একুশ',
    22: 'বাইশ',
    23: 'তেইশ',
    24: 'চব্বিশ',
    25: 'পঁচিশ',
    26: 'ছাব্বিশ',
    27: 'সাতাশ',
    28: 'আঠাশ',
    29: 'ঊনত্রিশ',
    30: 'ত্রিশ',
    31: 'একত্রিশ',
    32: 'বত্রিশ',
    33: 'তেত্রিশ',
    34: 'চৌত্রিশ',
    35: 'পঁয়ত্রিশ',
    36: 'ছত্রিশ',
    37: 'সাঁইত্রিশ',
    38: 'আটত্রিশ',
    39: 'ঊনচল্লিশ',
    40: 'চল্লিশ',
    41: 'একচল্লিশ',
    42: 'বিয়াল্লিশ',
    43: 'তেতাল্লিশ',
    44: 'চুয়াল্লিশ',
    45: 'পঁয়তাল্লিশ',
    46: 'ছেচল্লিশ',
    47: 'সাতচল্লিশ',
    48: 'আটচল্লিশ',
    49: 'ঊনপঞ্চাশ',
    50: 'পঞ্চাশ',
    51: 'একান্ন',
    52: 'বাহান্ন',
    53: 'তিপ্পান্ন',
    54: 'চুয়ান্ন',
    55: 'পঞ্চান্ন',
    56: 'ছাপ্পান্ন',
    57: 'সাতান্ন',
    58: 'আটান্ন',
    59: 'ঊনষাট',
    60: 'ষাট',
    61: 'একষট্টি',
    62: 'বাষট্টি',
    63: 'তেষট্টি',
    64: 'চৌষট্টি',
    65: 'পঁয়ষট্টি',
    66: 'ছেষট্টি',
    67: 'সাতষট্টি',
    68: 'আটষট্টি',
    69: 'ঊনসত্তর',
    70: 'সত্তর',
    71: 'একাত্তর',
    72: 'বাহাত্তর',
    73: 'তিয়াত্তর',
    74: 'চুয়াত্তর',
    75: 'পঁচাত্তর',
    76: 'ছিয়াত্তর',
    77: 'সাতাত্তর',
    78: 'আটাত্তর',
    79: 'ঊনআশি',
    80: 'আশি',
    81: 'একাশি',
    82: 'বিরাশি',
    83: 'তিরাশি',
    84: 'চুরাশি',
    85: 'পঁচাশি',
    86: 'ছিয়াশি',
    87: 'সাতাশি',
    88: 'আটাশি',
    89: 'ঊননব্বই',
    90: 'নব্বই',
    91: 'একানব্বই',
    92: 'বিরানব্বই',
    93: 'তিরানব্বই',
    94: 'চুরানব্বই',
    95: 'পঁচানব্বই',
    96: 'ছিয়ানব্বই',
    97: 'সাতানব্বই',
    98: 'আটানব্বই',
    99: 'নিরানব্বই'
}

_BN2EN = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")
_MONTHS = ["", "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
           "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"]

ABBREVIATIONS = {
    "ডা.": "ডাক্তার", "ড.": "ডক্টর", "মো.": "মোহাম্মদ", "মোঃ": "মোহাম্মদ", "মি.": "মিস্টার",
    "প্রফ.": "প্রফেসর", "নং": "নম্বর", "সে.মি.": "সেন্টিমিটার", "কি.মি.": "কিলোমিটার",
    "কে.জি.": "কিলোগ্রাম", "মি.লি.": "মিলিলিটার",
    "বি.এ.": "বি এ", "এম.এ.": "এম এ", "পিএইচডি": "পি এইচ ডি",
}

# নিজের শব্দ যোগ করুন: ইংরেজি/ব্র্যান্ড নাম কীভাবে পড়বে
CUSTOM_LEXICON = {
    "AI": "এআই", "Google": "গুগল", "YouTube": "ইউটিউব", "Facebook": "ফেসবুক",
    "WhatsApp": "হোয়াটসঅ্যাপ", "OK": "ওকে", "Mr.": "মিস্টার", "Dr.": "ডক্টর",
}

def int_to_bn_words(n: int) -> str:
    """বাংলা (দক্ষিণ এশীয়) পদ্ধতিতে: হাজার, লাখ, কোটি।"""
    if n < 0:
        return "ঋণাত্মক " + int_to_bn_words(-n)
    if n < 100:
        return _SMALL[n]
    parts = []
    for value, name in ((10_000_000, "কোটি"), (100_000, "লাখ"), (1000, "হাজার")):
        if n >= value:
            c, n = divmod(n, value)
            parts.append(int_to_bn_words(c) + " " + name)
    if n >= 100:
        h, n = divmod(n, 100)
        parts.append(_SMALL[h] + "শো")
    if n > 0:
        parts.append(_SMALL[n])
    return " ".join(parts) if parts else _SMALL[0]

def _num_str_to_words(s: str) -> str:
    s = s.replace(",", "")
    if "." in s:
        a, b = s.split(".", 1)
        out = int_to_bn_words(int(a or 0))
        if b:
            out += " দশমিক " + " ".join(_SMALL[int(d)] for d in b)
        return out
    return int_to_bn_words(int(s))

def _digits_spoken(s: str) -> str:
    return " ".join(_SMALL[int(d)] for d in s if d.isdigit())

class BanglaNormalizer:
    def __init__(self, lexicon=None, add_final_danda=True):
        self.lex = {**CUSTOM_LEXICON, **(lexicon or {})}
        self.add_final_danda = add_final_danda

    def _fix_unicode(self, t):
        t = t.replace("\ufeff", "").replace("\u200c", "").replace("\u200d", "")
        t = unicodedata.normalize("NFC", t)
        # NFC ড়/ঢ়/য় কে ভেঙে ফেলে, আবার জোড়া লাগাই (প্রচলিত বানান)
        t = t.replace("\u09a1\u09bc", "\u09dc").replace("\u09a2\u09bc", "\u09dd").replace("\u09af\u09bc", "\u09df")
        # ো / ৌ এর ভাঙা রূপ ঠিক করা
        t = t.replace("\u09c7\u09be", "\u09cb").replace("\u09c7\u09d7", "\u09cc")
        return t

    def _punct(self, t):
        for a, b in {"|": "।", "“": '"', "”": '"', "‘": "'", "’": "'", "…": "...", "—": ", ", "–": ", ",
                     "\u2018": "'", "\u2019": "'"}.items():
            t = t.replace(a, b)
        t = re.sub(r"[ \t]+", " ", t)
        t = re.sub(r"([।?!,;])\1+", r"\1", t)
        return t.strip()

    def normalize(self, text: str) -> str:
        t = self._fix_unicode(text)
        for k in sorted(ABBREVIATIONS, key=len, reverse=True):
            t = t.replace(k, ABBREVIATIONS[k])
        for k in sorted(self.lex, key=len, reverse=True):
            t = re.sub(r"(?<![A-Za-z])" + re.escape(k) + r"(?![A-Za-z])", self.lex[k], t)
        t = t.translate(_BN2EN)

        # তারিখ  ১৫/০৮/২০২৪ (দিন/মাস/বছর)
        def _date(m):
            d, mo, y = int(m.group(1)), int(m.group(2)), m.group(3)
            if 1 <= mo <= 12 and 1 <= d <= 31:
                return f"{int_to_bn_words(d)} {_MONTHS[mo]} {_num_str_to_words(y)}"
            return m.group(0)
        t = re.sub(r"\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})\b", _date, t)

        # সময় ৫:৩০
        def _time(m):
            h, mi = int(m.group(1)), int(m.group(2))
            if h < 24 and mi < 60:
                return f"{int_to_bn_words(h)}টা" + (f" {int_to_bn_words(mi)} মিনিট" if mi else "")
            return m.group(0)
        t = re.sub(r"\b(\d{1,2}):(\d{2})\b", _time, t)

        # ফোন নম্বর / লম্বা সংখ্যা: অঙ্ক ধরে ধরে
        t = re.sub(r"(?<![\d.,])\+?(?:88)?0?\d{9,}(?![\d])", lambda m: _digits_spoken(m.group(0)), t)

        # টাকা, ডলার, শতাংশ
        t = re.sub(r"৳\s*(\d[\d,]*(?:\.\d+)?)", lambda m: _num_str_to_words(m.group(1)) + " টাকা", t)
        t = re.sub(r"(\d[\d,]*(?:\.\d+)?)\s*৳", lambda m: _num_str_to_words(m.group(1)) + " টাকা", t)
        t = re.sub(r"\$\s*(\d[\d,]*(?:\.\d+)?)", lambda m: _num_str_to_words(m.group(1)) + " ডলার", t)
        t = re.sub(r"(\d[\d,]*(?:\.\d+)?)\s*%", lambda m: _num_str_to_words(m.group(1)) + " শতাংশ", t)

        # বাকি সংখ্যা
        t = re.sub(r"\d[\d,]*(?:\.\d+)?", lambda m: _num_str_to_words(m.group(0).rstrip(",")), t)

        t = self._punct(t)
        if self.add_final_danda and t and t[-1] not in "।?!.\"'":
            t += "।"
        return t

normalizer = BanglaNormalizer()
for s in ["আমার ২৫ টাকা আছে", "দাম ৳১,২৫,০০০ মাত্র", "তারিখ ১৫/০৮/২০২৪, সময় ৫:৩০", "ফোন: ০১৭১২৩৪৫৬৭৮", "৩.৫% বৃদ্ধি, ১২৩৪৫৬৭ জন"]:
    print(s, "→", normalizer.normalize(s))

# ══════ নোটবুক সেল 7 ══════
#@title রেফারেন্স অডিও টুলস
import os
import numpy as np, librosa, soundfile as sf, noisereduce as nr, pyloudnorm as pyln

SR = 24000

def load_mono(path, sr=SR):
    y, _ = librosa.load(path, sr=sr, mono=True)
    return y.astype(np.float32)

def enhance(y, sr=SR, denoise=True, target_lufs=-23.0):
    if denoise:
        y = nr.reduce_noise(y=y, sr=sr, stationary=False, prop_decrease=0.6)
    try:
        meter = pyln.Meter(sr)
        loud = meter.integrated_loudness(y)
        if np.isfinite(loud):
            y = pyln.normalize.loudness(y, loud, target_lufs)
    except Exception:
        pass
    peak = np.max(np.abs(y)) + 1e-9
    if peak > 0.97:
        y = y * (0.97 / peak)
    return y.astype(np.float32)

def best_segment(y, sr=SR, min_sec=4.0, max_sec=10.0, top_db=32):
    """কথা-সমৃদ্ধ, কম-নীরবতার সবচেয়ে ভালো ৪–১০ সেকেন্ড অংশ বেছে নেয়।"""
    segs = librosa.effects.split(y, top_db=top_db, frame_length=1024, hop_length=256)
    if len(segs) == 0:
        return y
    best, best_score = None, -1
    for i in range(len(segs)):
        start = segs[i][0]; speech = 0; end = start
        for j in range(i, len(segs)):
            gap = (segs[j][0] - end) / sr if j > i else 0
            span = (segs[j][1] - start) / sr
            if span > max_sec or gap > 0.8:
                break
            speech += (segs[j][1] - segs[j][0]) / sr
            end = segs[j][1]
            if speech >= min_sec:
                score = min(speech, 8.0) + 0.5 * (speech / max(span, 1e-3))
                if score > best_score:
                    best, best_score = (start, end), score
    if best is None:  # বিরতিহীন লম্বা বা খুব ছোট অডিও: max_sec পর্যন্ত নেওয়া
        seg = y[segs[0][0]: segs[-1][1]]
        return seg[: int(max_sec * sr)]
    pad = int(0.1 * sr)
    return y[max(0, best[0] - pad): min(len(y), best[1] + pad)]

def quality_report(y, sr=SR):
    dur = len(y) / sr
    frame = 1024
    rms = librosa.feature.rms(y=y, frame_length=frame, hop_length=256)[0] + 1e-9
    db = 20 * np.log10(rms)
    noise = np.percentile(db, 10); speech = np.percentile(db, 90)
    snr = float(speech - noise)
    clip = float(np.mean(np.abs(y) > 0.99))
    notes = []
    if dur < 3: notes.append("⚠️ অডিও ৩ সেকেন্ডের কম: আরও লম্বা নমুনা দিন")
    if snr < 15: notes.append("⚠️ ব্যাকগ্রাউন্ড নয়েজ বেশি (SNR কম): শান্ত ঘরে রেকর্ড করুন")
    if clip > 0.001: notes.append("⚠️ ক্লিপিং/ফাটা আওয়াজ আছে: মাইক থেকে একটু দূরে বা নিচু ভলিউমে রেকর্ড করুন")
    if not notes: notes.append("✅ ভালো মানের রেফারেন্স")
    return {"duration_sec": round(dur, 2), "snr_db": round(snr, 1), "clip_ratio": round(clip, 5), "notes": notes}

def prepare_reference(path, denoise=True, pick_best=True, out_path=None):
    out_path = out_path or f"{WORK_DIR}/ref_clean.wav"
    if not path or not os.path.isfile(path):
        raise FileNotFoundError(f"রেফারেন্স অডিও ফাইল পাওয়া যায়নি: {path}")
    try:
        y = load_mono(path)
    except Exception as e:
        raise ValueError(f"রেফারেন্স অডিও পড়া যায়নি (wav/mp3/flac/m4a দিন): {e}") from e
    if len(y) < SR * 1.0 or float(np.max(np.abs(y))) < 1e-4:
        raise ValueError("রেফারেন্স অডিও খুব ছোট বা ফাঁকা। ৫–১৫ সেকেন্ডের পরিষ্কার কথা দিন।")
    if pick_best:
        y = best_segment(y)          # আগে ছোট করা: নয়েজ রিমুভ অনেক দ্রুত হয়
    y = enhance(y, denoise=denoise)
    sf.write(out_path, y, SR)
    return out_path, quality_report(y)


# ══════ নোটবুক সেল 9 ══════
#@title মডেল লোড
import torch, time, threading, os
from omnivoice import OmniVoice, VoiceClonePrompt

MODEL_ID = "k2-fsa/OmniVoice"
torch.set_num_threads(os.cpu_count() or 1)
if globals().get("model") is None:   # একই মডেল দুইবার RAM-এ লোড হবে না
    try:
        model = OmniVoice.from_pretrained(MODEL_ID, device_map="cpu", dtype=torch.float32, load_asr=False)   # Whisper আলাদা থ্রেডে লোড হবে, অপেক্ষা করতে হবে না
    except Exception as e:
        raise RuntimeError(f"❌ মডেল ডাউনলোড/লোড ব্যর্থ ({MODEL_ID}): ইন্টারনেট ও ডিস্কের জায়গা দেখে সেলটি আবার চালান। বিস্তারিত: {e}") from e
# (CUDA/TF32/cudnn সেটিং CPU সার্ভারে লাগে না, তাই বন্ধ)
# if torch.cuda.is_available(): torch.backends.cuda.matmul.allow_tf32 = True
# if torch.cuda.is_available(): torch.backends.cudnn.benchmark = False  # দৈর্ঘ্য বদলালে বারবার টিউনিং করে ধীর করত
print("মডেল লোড হয়েছে ✅  | বাংলা (bn) সাপোর্টেড:", "bn" in model.supported_language_ids())

_asr_lock = threading.Lock()
def ensure_asr():
    """Whisper দরকার হলে (বা ব্যাকগ্রাউন্ডে) একবারই লোড হয়।"""
    with _asr_lock:
        if getattr(model, "_asr_pipe", None) is None:
            model.load_asr_model()
def _bg_asr():
    try: ensure_asr()
    except Exception as e: print("ASR ব্যাকগ্রাউন্ড লোড হয়নি:", e)
threading.Thread(target=_bg_asr, daemon=True).start()

def transcribe_bn(wav_path):
    """বাংলা Whisper ট্রান্সক্রিপশন (ভাষা জোর করে bengali ধরা হয়)।"""
    ensure_asr()
    y = load_mono(wav_path, 16000)
    try:
        out = model._asr_pipe({"raw": y, "sampling_rate": 16000},
                              generate_kwargs={"language": "bengali", "task": "transcribe"})
        return out["text"].strip()
    except Exception as e:
        print("fallback ASR:", e)
        return model.transcribe(wav_path)
# ওয়ার্ম-আপ এখানে আলাদাভাবে চালানো হয় না (সময় বাঁচাতে) — Turbo Engine সেলের ব্যাচ ওয়ার্ম-আপই কার্নেল গরম করে দেয়


# ══════ নোটবুক সেল 11 ══════
#@title ভয়েস লাইব্রেরি
import json, os, shutil, datetime, re

def _slug(name):
    return re.sub(r"[^\w\u0980-\u09FF\-]+", "_", name.strip()) or "voice"

def create_voice(name, audio_path, ref_text=None, consent=False, denoise=True, pick_best=True):
    if not consent:
        raise ValueError("সম্মতি (consent) নিশ্চিত করুন: এই কণ্ঠ আপনার নিজের বা অনুমতিপ্রাপ্ত।")
    vid = _slug(name)
    vdir = f"{LIB_DIR}/voices/{vid}"
    os.makedirs(vdir, exist_ok=True)
    clean, report = prepare_reference(audio_path, denoise=denoise, pick_best=pick_best, out_path=f"{vdir}/ref.wav")
    text = (ref_text or "").strip() or transcribe_bn(clean)
    text = normalizer.normalize(text)
    prompt = model.create_voice_clone_prompt(ref_audio=clean, ref_text=text)
    prompt.save(f"{vdir}/prompt.pt")
    meta = {"name": name, "ref_text": text, "created": datetime.datetime.now().isoformat(timespec="seconds"),
            "consent_confirmed": True, "quality": report, "model": MODEL_ID}
    json.dump(meta, open(f"{vdir}/meta.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return vid, meta

def list_voices():
    d = f"{LIB_DIR}/voices"
    return sorted(x for x in os.listdir(d) if os.path.exists(f"{d}/{x}/prompt.pt")) if os.path.isdir(d) else []

_cache = {}
def load_voice(vid):
    if vid not in _cache:
        _cache[vid] = VoiceClonePrompt.load(f"{LIB_DIR}/voices/{vid}/prompt.pt")
    return _cache[vid]

def delete_voice(vid):
    shutil.rmtree(f"{LIB_DIR}/voices/{vid}", ignore_errors=True); _cache.pop(vid, None)

print("সংরক্ষিত ভয়েস:", list_voices())

# ══════ নোটবুক সেল 13 ══════
#@title সিনথেসিস ইঞ্জিন
import numpy as np, jiwer, re, time, random, torch

_SENT_SPLIT = re.compile(r"(?<=[।?!])\s*|\n+")
_SOFT_SPLIT = re.compile(r"(?<=[,;:،])\s+")

def split_text(text, max_chars=160):
    """বাক্য → চাঙ্ক। প্রতিটির সাথে পরবর্তী বিরতির (pause) সময় (সেকেন্ড)।"""
    items = []
    for para in re.split(r"\n\s*\n", text.strip()):
        sents = [s.strip() for s in _SENT_SPLIT.split(para) if s.strip()]
        for si, s in enumerate(sents):
            pieces = [s]
            if len(s) > max_chars:
                parts, cur = _SOFT_SPLIT.split(s), ""
                pieces = []
                for p in parts:
                    if cur and len(cur) + len(p) + 1 > max_chars:
                        pieces.append(cur); cur = p
                    else:
                        cur = (cur + " " + p).strip()
                if cur: pieces.append(cur)
                final = []
                for p in pieces:  # এখনও লম্বা হলে শব্দের সীমানায় কাটা
                    while len(p) > max_chars * 1.4:
                        cut = p.rfind(" ", 0, max_chars)
                        cut = cut if cut > 20 else max_chars
                        final.append(p[:cut]); p = p[cut:].strip()
                    final.append(p)
                pieces = final
            for pi, p in enumerate(pieces):
                last_piece = pi == len(pieces) - 1
                if not last_piece:
                    pause = 0.15
                elif si == len(sents) - 1:
                    pause = 0.7  # অনুচ্ছেদ শেষ
                elif p[-1] in "?!":
                    pause = 0.45
                else:
                    pause = 0.35
                items.append((p, pause))
    return items

def _clean_for_cer(s):
    return re.sub(r"[^\u0980-\u09FFA-Za-z0-9]", "", s)

def _fade(y, sr, ms=12):
    n = int(sr * ms / 1000)
    if len(y) > 2 * n:
        y = y.copy(); y[:n] *= np.linspace(0, 1, n); y[-n:] *= np.linspace(1, 0, n)
    return y

def synthesize(text, voice_id=None, speed=1.0, num_step=16, guidance_scale=2.0, seed=None,
               best_of=1, do_normalize=True, max_chars=160, instruct=None, prompt=None, progress=None):
    """রিটার্ন: (audio float32 @24k, report string)"""
    t0 = time.time()
    if do_normalize:
        text = "\n".join(normalizer.normalize(line) if line.strip() else "" for line in text.split("\n"))
    prompt = prompt or (load_voice(voice_id) if voice_id else None)
    items = split_text(text, max_chars)
    if not items:
        raise ValueError("টেক্সট খালি")
    base_seed = seed if seed not in (None, -1) else random.randint(0, 10**6)
    if best_of > 1: ensure_asr()
    use_asr = best_of > 1 and getattr(model, "_asr_pipe", None) is not None
    out, log = [], []
    for i, (chunk, pause) in enumerate(items):
        if progress: progress(i / len(items), desc=f"{int(i / len(items) * 100)}% — চাঙ্ক {i+1}/{len(items)}")
        best_audio, best_cer = None, 9.9
        for k in range(max(1, best_of)):
            torch.manual_seed(base_seed + i * 1000 + k)
            kw = dict(text=chunk, language="bn", speed=speed, num_step=num_step, guidance_scale=guidance_scale)
            if prompt is not None: kw["voice_clone_prompt"] = prompt
            if instruct: kw["instruct"] = instruct
            audio = model.generate(**kw)[0].astype(np.float32)
            if not use_asr:
                best_audio, best_cer = audio, -1
                break
            hyp = normalizer.normalize(transcribe_array(audio))
            c = jiwer.cer(_clean_for_cer(re.sub(r"\[[^\]]*\]", "", chunk)), _clean_for_cer(hyp) or "x")
            if c < best_cer:
                best_audio, best_cer = audio, c
            if c <= 0.08:  # যথেষ্ট ভালো, আর চেষ্টা লাগবে না
                break
        out.append(_fade(best_audio, SR)); out.append(np.zeros(int(SR * pause), dtype=np.float32))
        log.append(f"[{i+1}] CER={best_cer:.2f} | {chunk[:45]}" if best_cer >= 0 else f"[{i+1}] {chunk[:45]}")
    if progress: progress(1.0, desc="১০০% — সম্পন্ন")
    y = np.concatenate(out)
    y = y / (np.max(np.abs(y)) + 1e-9) * 0.89  # ≈ -1 dBFS
    dur = len(y) / SR
    rep = f"সময়: {dur:.1f}s | জেনারেশন: {time.time()-t0:.1f}s (RTF {(time.time()-t0)/max(dur,1e-3):.2f}) | চাঙ্ক: {len(items)} | seed: {base_seed}\n" + "\n".join(log)
    return y, rep

def transcribe_array(y, sr=SR):
    ensure_asr()
    y16 = librosa.resample(y, orig_sr=sr, target_sr=16000)
    return model._asr_pipe({"raw": y16, "sampling_rate": 16000},
                           generate_kwargs={"language": "bengali", "task": "transcribe"})["text"].strip()

def console_progress(prefix="জেনারেট"):
    """Colab আউটপুটে লাইভ প্রগ্রেস বার + শতাংশ দেখায়: synthesize(..., progress=console_progress())"""
    def cb(frac, desc=""):
        frac = max(0.0, min(1.0, float(frac)))
        n = int(frac * 20)
        line = f"{prefix} [{'█' * n}{'░' * (20 - n)}] {frac * 100:5.1f}%  {desc}"
        print("\r" + line.ljust(90), end="\n" if frac >= 1.0 else "", flush=True)
    return cb

print("প্রস্তুত | টেস্ট চাঙ্কিং:", split_text("আমি বাংলায় কথা বলি। তুমি কেমন আছো? ভালো আছি, ধন্যবাদ!"))

# ══════ নোটবুক সেল 15 ══════
#@title ⚡ Turbo Engine — OmniVoice সোর্স কোড থেকে তৈরি (ব্যাচিং + স্ট্রিমিং + ক্যাশ)
import numpy as np, torch, time, re, random, threading, queue, collections, contextlib

# ── ১) KV-cache বন্ধ ────────────────────────────────────────────────
# OmniVoice প্রতি ধাপে পুরো সিকোয়েন্স bidirectional-ভাবে নতুন করে হিসাব করে, তাই HF-এর DynamicCache
# শুধু বাড়তি খরচ (omnivoice_flashinfer.py-র নিজের মন্তব্যেও এটাই লেখা আছে)।
try:
    model.llm.config.use_cache = False
except Exception as _e:
    print("use_cache বন্ধ করা যায়নি:", _e)

# ── ২) ছোট LRU ক্যাশ: একই বাক্য আবার বললে সঙ্গে সঙ্গে ─────────────────
_TC = collections.OrderedDict(); _TC_LOCK = threading.Lock(); _TC_MAX = 256
def _tc_get(k):
    with _TC_LOCK:
        v = _TC.get(k)
        if v is not None: _TC.move_to_end(k)
        return v
def _tc_put(k, v):
    with _TC_LOCK:
        _TC[k] = v; _TC.move_to_end(k)
        while len(_TC) > _TC_MAX: _TC.popitem(last=False)
def turbo_cache_clear():
    with _TC_LOCK: _TC.clear()

# ── ৩) হালকা পোস্ট-প্রসেস ───────────────────────────────────────────
# OmniVoice-এর ডিফল্ট পোস্ট-প্রসেস pydub দিয়ে CPU-তে সাইলেন্স কাটে (ধীর) এবং দুই পাশে ০.১s ফাঁকা যোগ করে।
# এখানে সেটি বন্ধ রেখে সস্তা numpy ট্রিম ব্যবহার হয়েছে; ভলিউম (ref_rms) মডেল নিজেই ঠিক করে দেয়।
def _trim_edges(y, sr=SR, keep_ms=70, rel_db=-45):
    if len(y) == 0: return y
    a = np.abs(y); pk = float(a.max())
    if pk < 1e-4: return y
    idx = np.flatnonzero(a > pk * (10 ** (rel_db / 20)))
    if len(idx) == 0: return y
    k = int(sr * keep_ms / 1000)
    return y[max(0, idx[0] - k): min(len(y), idx[-1] + k)]

def _gen_batch(texts, prompt, speed, steps, guide, seed):
    """একাধিক বাক্য একসাথে একটি ব্যাচে (public generate API; লিস্ট দিলে মডেল নিজেই ব্যাচ করে)।"""
    def run(tx):
        torch.manual_seed(seed)
        outs = model.generate(text=tx, language="bn", voice_clone_prompt=prompt, speed=speed,
                              num_step=steps, guidance_scale=guide,
                              postprocess_output=False, pad_duration=0.0, fade_duration=0.0)
        return [_fade(_trim_edges(np.asarray(o, dtype=np.float32).reshape(-1)), SR) for o in outs]
    try:
        return run(texts)
    except Exception as e:                      # ব্যাচ ব্যর্থ (যেমন VRAM) হলে একটি একটি করে
        print("ব্যাচ ব্যর্থ, একটি একটি করে চলছে:", str(e)[:120])
        import gc; gc.collect()
        return [run([t])[0] for t in texts]

# ── ৪) স্ট্রিমিং জেনারেটর ──────────────────────────────────────────
TURBO_LAST = {}
def turbo_stream(text, voice_id, speed=1.0, steps=12, first_steps=8, guide=2.0, seed=-1,
                 do_normalize=True, max_chars=160, batch_chars=240, lock=None, stats=None):
    """(audio float32 @24k, pause_sec) টুকরো টুকরো করে yield করে।
    • প্রথম ব্যাচ = শুধু প্রথম বাক্য, কম স্টেপে → প্রথম শব্দ খুব দ্রুত আসে।
    • বাকি বাক্য ~batch_chars অক্ষরের ব্যাচে একসাথে তৈরি হয় (GPU-তে ব্যাচ অনেক সস্তা)।
    • জেনারেশন আলাদা থ্রেডে এগিয়ে থাকে, বাজানো ও জেনারেশন একসাথে চলে।"""
    t0 = time.time()
    st = stats if stats is not None else {}
    if do_normalize:
        text = "\n".join(normalizer.normalize(l) if l.strip() else "" for l in text.split("\n"))
    prompt = load_voice(voice_id)
    items = split_text(text, max_chars)
    if not items: raise ValueError("টেক্সট খালি")
    if len(items[0][0]) > 90:                   # লম্বা প্রথম বাক্য কমা-তে ভেঙে দ্রুত শুরু
        c, p = items[0]; m = re.search(r"[,;:،]\s", c[20:90])
        if m:
            k = 20 + m.end(); items[0:1] = [(c[:k].strip(), 0.08), (c[k:].strip(), p)]
    batches, cur, cc = [], [], 0
    for it in items:
        if not batches and not cur: batches.append([it]); continue
        cur.append(it); cc += len(it[0])
        if cc >= batch_chars or len(cur) >= 6: batches.append(cur); cur, cc = [], 0
    if cur: batches.append(cur)
    base = seed if seed not in (None, -1) else random.randint(0, 10**6)
    fs = first_steps or steps
    q, stop = queue.Queue(), threading.Event()
    st.update(batches=len(batches), sentences=len(items), cache_hits=0, first_audio_s=None)

    def producer():
        try:
            with (lock if lock is not None else contextlib.nullcontext()):
                for bi, batch in enumerate(batches):
                    if stop.is_set(): break
                    stp = fs if bi == 0 else steps
                    keys = [(voice_id, t, round(speed, 3), stp, round(guide, 2)) for t, _ in batch]
                    aud = [_tc_get(k) for k in keys]
                    todo = [j for j, a in enumerate(aud) if a is None]
                    st["cache_hits"] += len(batch) - len(todo)
                    if todo:
                        outs = _gen_batch([batch[j][0] for j in todo], prompt, speed, stp, guide, base + bi * 1000)
                        for j, o in zip(todo, outs): aud[j] = o; _tc_put(keys[j], o)
                    for (_, pause), a in zip(batch, aud): q.put((a, pause))
        except Exception as e:
            q.put(e)
        finally:
            q.put(None)

    th = threading.Thread(target=producer, daemon=True); th.start()
    audio_sec = 0.0
    try:
        while True:
            it = q.get()
            if it is None: break
            if isinstance(it, Exception): raise it
            if st["first_audio_s"] is None: st["first_audio_s"] = round(time.time() - t0, 3)
            audio_sec += len(it[0]) / SR + it[1]
            yield it
    finally:
        stop.set()
        el = time.time() - t0
        st.update(total_s=round(el, 3), audio_s=round(audio_sec, 2), rtf=round(el / max(audio_sec, 1e-3), 3))
        TURBO_LAST.clear(); TURBO_LAST.update(st)

def synthesize_fast(text, voice_id=None, speed=1.0, num_step=16, guidance_scale=2.0, seed=None,
                    best_of=1, do_normalize=True, max_chars=160, instruct=None, prompt=None, progress=None):
    """synthesize()-র মতোই (audio, report) দেয়, কিন্তু ব্যাচিং/ক্যাশ সহ দ্রুত।
    best_of>1 / instruct / কাস্টম prompt হলে আগের ইঞ্জিনেই ফিরে যায়।"""
    slow = lambda: synthesize(text, voice_id, speed=speed, num_step=num_step, guidance_scale=guidance_scale,
                              seed=seed, best_of=best_of, do_normalize=do_normalize, max_chars=max_chars,
                              instruct=instruct, prompt=prompt, progress=progress)
    if best_of > 1 or instruct or prompt is not None or not voice_id: return slow()
    try:
        st, parts = {}, []
        if progress: progress(0.0, desc="০% — শুরু")
        for a, pause in turbo_stream(text, voice_id, speed=speed, steps=num_step, first_steps=num_step,
                                     guide=guidance_scale, seed=-1 if seed is None else seed,
                                     do_normalize=do_normalize, max_chars=max_chars, stats=st):
            parts += [a, np.zeros(int(SR * pause), dtype=np.float32)]
            if progress:
                _done, _tot = len(parts) // 2, max(1, st.get("sentences", 1))
                progress(min(_done / _tot, 1.0), desc=f"{int(min(_done / _tot, 1.0) * 100)}% — বাক্য {_done}/{_tot}")
        if progress: progress(1.0, desc="১০০% — সম্পন্ন")
        y = np.concatenate(parts); y = y / (np.max(np.abs(y)) + 1e-9) * 0.89
        rep = (f"⚡ Turbo | সময়: {len(y)/SR:.1f}s | জেনারেশন: {st['total_s']:.1f}s (RTF {st['rtf']:.2f}) | "
               f"প্রথম শব্দ: {st['first_audio_s']}s | ব্যাচ: {st['batches']} | ক্যাশ-হিট: {st['cache_hits']}")
        return y, rep
    except Exception as e:
        print("Turbo ব্যর্থ, আগের ইঞ্জিনে ফিরছি:", str(e)[:150]); return slow()

# ── ৫) ওয়ার্ম-আপ: ব্যাচ-আকারের কার্নেল আগে থেকেই গরম করা ───────────────
try:
    model.generate(text=["আমি বাংলায় কথা বলি।", "তুমি কেমন আছো?"], language="bn", num_step=4,
                   postprocess_output=False)
    print("⚡ Turbo Engine প্রস্তুত — ব্যাচ ওয়ার্ম-আপ সম্পন্ন")
except Exception as e:
    print("ওয়ার্ম-আপ বাদ:", str(e)[:120])

# ══════ নোটবুক সেল 20 ══════
#@title index.html স্বয়ংক্রিয়ভাবে সেটআপ (Any people bd voice clone UI)
import base64, os
_INDEX_B64 = (
    "PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImJuIj4KPGhlYWQ+CjxtZXRhIGNoYXJzZXQ9InV0Zi04Ij4KPG1ldGEgbmFtZT0i"
    "dmlld3BvcnQiIGNvbnRlbnQ9IndpZHRoPWRldmljZS13aWR0aCwgaW5pdGlhbC1zY2FsZT0xIj4KPHRpdGxlPkFueSBwZW9wbGUg"
    "YmQgdm9pY2UgY2xvbmU8L3RpdGxlPgo8bGluayBocmVmPSJodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5"
    "PU5vdG8rU2FucytCZW5nYWxpOndnaHRANDAwOzYwMDs3MDAmZGlzcGxheT1zd2FwIiByZWw9InN0eWxlc2hlZXQiPgo8c3R5bGU+"
    "Cjpyb290ey0tYmc6IzBmMTQyMDstLWNhcmQ6IzE3MWUyZTstLWxpbmU6IzI3MzE0YTstLXR4OiNlOGVjZjU7LS1tdXQ6IzhiOTdi"
    "MzstLWFjOiMyZGQ0YTA7LS1hYzI6IzFmYTU3ZDstLWVycjojZmY2YjZifQpAbWVkaWEocHJlZmVycy1jb2xvci1zY2hlbWU6bGln"
    "aHQpezpyb290ey0tYmc6I2YzZjZmYjstLWNhcmQ6I2ZmZjstLWxpbmU6I2Q5ZTBlZTstLXR4OiMxYjI0Mzg7LS1tdXQ6IzVkNmE4"
    "NjstLWFjOiMwZjllNzI7LS1hYzI6IzBiN2Q1YX19Cip7Ym94LXNpemluZzpib3JkZXItYm94fQpib2R5e21hcmdpbjowO2JhY2tn"
    "cm91bmQ6dmFyKC0tYmcpO2NvbG9yOnZhcigtLXR4KTtmb250OjE2cHgvMS42ICJOb3RvIFNhbnMgQmVuZ2FsaSIsc3lzdGVtLXVp"
    "LHNhbnMtc2VyaWZ9Ci53e21heC13aWR0aDo4NjBweDttYXJnaW46YXV0bztwYWRkaW5nOjE2cHh9Cmgxe2ZvbnQtc2l6ZToyMnB4"
    "O21hcmdpbjo2cHggMCAycHh9LnN1Yntjb2xvcjp2YXIoLS1tdXQpO2ZvbnQtc2l6ZToxNHB4O21hcmdpbi1ib3R0b206MTRweH0K"
    "LmNhcmR7YmFja2dyb3VuZDp2YXIoLS1jYXJkKTtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2JvcmRlci1yYWRpdXM6MTRw"
    "eDtwYWRkaW5nOjE2cHg7bWFyZ2luLWJvdHRvbToxNHB4fQpsYWJlbHtkaXNwbGF5OmJsb2NrO2ZvbnQtc2l6ZToxNHB4O2NvbG9y"
    "OnZhcigtLW11dCk7bWFyZ2luOjEwcHggMCA0cHh9CmlucHV0W3R5cGU9dGV4dF0saW5wdXRbdHlwZT1wYXNzd29yZF0saW5wdXRb"
    "dHlwZT1udW1iZXJdLHNlbGVjdCx0ZXh0YXJlYXt3aWR0aDoxMDAlO3BhZGRpbmc6MTBweCAxMnB4O2JvcmRlci1yYWRpdXM6MTBw"
    "eDtib3JkZXI6MXB4IHNvbGlkIHZhcigtLWxpbmUpO2JhY2tncm91bmQ6dmFyKC0tYmcpO2NvbG9yOnZhcigtLXR4KTtmb250Omlu"
    "aGVyaXR9CnRleHRhcmVhe21pbi1oZWlnaHQ6MTMwcHg7cmVzaXplOnZlcnRpY2FsfQpidXR0b257Zm9udDppbmhlcml0O2N1cnNv"
    "cjpwb2ludGVyO2JvcmRlcjowO2JvcmRlci1yYWRpdXM6MTBweDtwYWRkaW5nOjEwcHggMTZweDtiYWNrZ3JvdW5kOnZhcigtLWFj"
    "KTtjb2xvcjojMDQyODFkO2ZvbnQtd2VpZ2h0OjYwMH0KYnV0dG9uLnNlY3tiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2JvcmRlcjox"
    "cHggc29saWQgdmFyKC0tbGluZSk7Y29sb3I6dmFyKC0tdHgpfQpidXR0b24uZG5ne2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Ym9y"
    "ZGVyOjFweCBzb2xpZCB2YXIoLS1lcnIpO2NvbG9yOnZhcigtLWVycik7cGFkZGluZzo2cHggMTBweH0KYnV0dG9uOmRpc2FibGVk"
    "e29wYWNpdHk6LjU7Y3Vyc29yOndhaXR9Ci5yb3d7ZGlzcGxheTpmbGV4O2dhcDoxMHB4O2ZsZXgtd3JhcDp3cmFwO2FsaWduLWl0"
    "ZW1zOmNlbnRlcn0ucm93Pip7ZmxleDoxIDEgMTQwcHh9LnJvdz5idXR0b257ZmxleDowIDAgYXV0b30KLnRhYnN7ZGlzcGxheTpm"
    "bGV4O2dhcDo4cHg7bWFyZ2luLWJvdHRvbToxNHB4fS50YWJzIGJ1dHRvbntmbGV4OjE7YmFja2dyb3VuZDp2YXIoLS1jYXJkKTtj"
    "b2xvcjp2YXIoLS10eCk7Ym9yZGVyOjFweCBzb2xpZCB2YXIoLS1saW5lKX0KLnRhYnMgYnV0dG9uLm9ue2JhY2tncm91bmQ6dmFy"
    "KC0tYWMpO2NvbG9yOiMwNDI4MWQ7Ym9yZGVyLWNvbG9yOnZhcigtLWFjKX0KLmRvdHtkaXNwbGF5OmlubGluZS1ibG9jazt3aWR0"
    "aDoxMHB4O2hlaWdodDoxMHB4O2JvcmRlci1yYWRpdXM6NTAlO2JhY2tncm91bmQ6dmFyKC0tZXJyKTttYXJnaW4tcmlnaHQ6NnB4"
    "fS5kb3Qub2t7YmFja2dyb3VuZDp2YXIoLS1hYyl9Ci5tc2d7Zm9udC1zaXplOjE0cHg7bWFyZ2luLXRvcDo4cHg7d2hpdGUtc3Bh"
    "Y2U6cHJlLXdyYXA7Y29sb3I6dmFyKC0tbXV0KX0ubXNnLmVycntjb2xvcjp2YXIoLS1lcnIpfQoudntkaXNwbGF5OmZsZXg7anVz"
    "dGlmeS1jb250ZW50OnNwYWNlLWJldHdlZW47YWxpZ24taXRlbXM6Y2VudGVyO2dhcDo4cHg7cGFkZGluZzoxMHB4IDA7Ym9yZGVy"
    "LXRvcDoxcHggc29saWQgdmFyKC0tbGluZSl9Ci52OmZpcnN0LWNoaWxke2JvcmRlci10b3A6MH0udiBzbWFsbHtjb2xvcjp2YXIo"
    "LS1tdXQpO2Rpc3BsYXk6YmxvY2t9CmF1ZGlve3dpZHRoOjEwMCU7bWFyZ2luLXRvcDoxMHB4fQpkZXRhaWxze21hcmdpbi10b3A6"
    "MTBweH1zdW1tYXJ5e2N1cnNvcjpwb2ludGVyO2NvbG9yOnZhcigtLW11dCl9Ci5jaGt7ZGlzcGxheTpmbGV4O2dhcDo4cHg7YWxp"
    "Z24taXRlbXM6ZmxleC1zdGFydDtmb250LXNpemU6MTRweDttYXJnaW4tdG9wOjEwcHh9LmNoayBpbnB1dHttYXJnaW4tdG9wOjZw"
    "eH0KLmhpZGV7ZGlzcGxheTpub25lfS50Z3tkaXNwbGF5OmZsZXg7Z2FwOjZweDtmbGV4LXdyYXA6d3JhcDttYXJnaW4tdG9wOjZw"
    "eH0udGcgYnV0dG9ue3BhZGRpbmc6NHB4IDEwcHg7Zm9udC1zaXplOjEzcHg7Zm9udC13ZWlnaHQ6NDAwfS5oe2Rpc3BsYXk6Zmxl"
    "eDtnYXA6OHB4O2FsaWduLWl0ZW1zOmNlbnRlcjtwYWRkaW5nOjhweCAwO2JvcmRlci10b3A6MXB4IHNvbGlkIHZhcigtLWxpbmUp"
    "O2ZvbnQtc2l6ZToxNHB4fS5oIHNwYW57ZmxleDoxO292ZXJmbG93OmhpZGRlbjt0ZXh0LW92ZXJmbG93OmVsbGlwc2lzO3doaXRl"
    "LXNwYWNlOm5vd3JhcH0uaCBidXR0b257cGFkZGluZzo0cHggMTBweH0KCi8qID09PT09IOCmleCmvuCmsuCmvuCmsOCmq+CngeCm"
    "siDgpoXgp43gpq/gpr7gpqjgpr/gpq7gp4fgprbgpqggKOCmtuCngeCmp+CngSDgpq3gpr/gppzgp43gpq/gp4Hgpq/gprzgpr7g"
    "prIsIOCmleCni+CmqOCniyDgprLgppzgpr/gppUg4Kas4Kam4Kay4Ka+4Kav4Ka84Kao4Ka/KSA9PT09PSAqLwpib2R5OjpiZWZv"
    "cmV7Y29udGVudDoiIjtwb3NpdGlvbjpmaXhlZDtpbnNldDotMjAlO3otaW5kZXg6LTE7cG9pbnRlci1ldmVudHM6bm9uZTtvcGFj"
    "aXR5Oi4zNTsKYmFja2dyb3VuZDpyYWRpYWwtZ3JhZGllbnQoY2lyY2xlIGF0IDIwJSAyNSUsI2ZmNGQ4ZCAwLHRyYW5zcGFyZW50"
    "IDMyJSkscmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCA4MCUgMjAlLCMyZGQ0YTAgMCx0cmFuc3BhcmVudCAzMCUpLHJhZGlhbC1n"
    "cmFkaWVudChjaXJjbGUgYXQgNzAlIDgwJSwjNGQ4ZGZmIDAsdHJhbnNwYXJlbnQgMzIlKSxyYWRpYWwtZ3JhZGllbnQoY2lyY2xl"
    "IGF0IDI1JSA4NSUsI2ZmZDI0ZCAwLHRyYW5zcGFyZW50IDI4JSk7CmZpbHRlcjpibHVyKDUwcHgpO2FuaW1hdGlvbjpiZ21vdmUg"
    "MThzIGVhc2UtaW4tb3V0IGluZmluaXRlIGFsdGVybmF0ZX0KQGtleWZyYW1lcyBiZ21vdmV7MCV7dHJhbnNmb3JtOnRyYW5zbGF0"
    "ZSgwLDApIHJvdGF0ZSgwKSBzY2FsZSgxKX01MCV7dHJhbnNmb3JtOnRyYW5zbGF0ZSg0JSwtMyUpIHJvdGF0ZSg4ZGVnKSBzY2Fs"
    "ZSgxLjEyKX0xMDAle3RyYW5zZm9ybTp0cmFuc2xhdGUoLTQlLDMlKSByb3RhdGUoLThkZWcpIHNjYWxlKDEpfX0KaDF7YmFja2dy"
    "b3VuZDpsaW5lYXItZ3JhZGllbnQoOTBkZWcsI2ZmNGQ4ZCwjZmZiODRkLCMyZGQ0YTAsIzRkOGRmZiwjYjQ0ZGZmLCNmZjRkOGQp"
    "O2JhY2tncm91bmQtc2l6ZTozMDAlIDEwMCU7LXdlYmtpdC1iYWNrZ3JvdW5kLWNsaXA6dGV4dDtiYWNrZ3JvdW5kLWNsaXA6dGV4"
    "dDstd2Via2l0LXRleHQtZmlsbC1jb2xvcjp0cmFuc3BhcmVudDthbmltYXRpb246ZmxvdyA2cyBsaW5lYXIgaW5maW5pdGV9Cmgx"
    "IHNwYW57LXdlYmtpdC10ZXh0LWZpbGwtY29sb3I6IzA0MjgxZH0KQGtleWZyYW1lcyBmbG93e3Rve2JhY2tncm91bmQtcG9zaXRp"
    "b246MzAwJSAwfX0KLmNhcmR7YW5pbWF0aW9uOmdsb3cgOHMgbGluZWFyIGluZmluaXRlO3RyYW5zaXRpb246dHJhbnNmb3JtIC4y"
    "NXN9Ci5jYXJkOmhvdmVye3RyYW5zZm9ybTp0cmFuc2xhdGVZKC0ycHgpfQpAa2V5ZnJhbWVzIGdsb3d7MCV7Ym9yZGVyLWNvbG9y"
    "OiNmZjRkOGQ7Ym94LXNoYWRvdzowIDAgMTRweCAjZmY0ZDhkMzN9MjUle2JvcmRlci1jb2xvcjojZmZiODRkO2JveC1zaGFkb3c6"
    "MCAwIDE0cHggI2ZmYjg0ZDMzfTUwJXtib3JkZXItY29sb3I6IzJkZDRhMDtib3gtc2hhZG93OjAgMCAxNHB4ICMyZGQ0YTAzM303"
    "NSV7Ym9yZGVyLWNvbG9yOiM0ZDhkZmY7Ym94LXNoYWRvdzowIDAgMTRweCAjNGQ4ZGZmMzN9MTAwJXtib3JkZXItY29sb3I6I2Zm"
    "NGQ4ZDtib3gtc2hhZG93OjAgMCAxNHB4ICNmZjRkOGQzM319CmJ1dHRvbjpub3QoLnNlYyk6bm90KC5kbmcpe2JhY2tncm91bmQ6"
    "bGluZWFyLWdyYWRpZW50KDkwZGVnLCMyZGQ0YTAsIzRkYzNmZiwjYjQ4ZGZmLCNmZjhkYzMsI2ZmZDI0ZCwjMmRkNGEwKTtiYWNr"
    "Z3JvdW5kLXNpemU6MzAwJSAxMDAlO2FuaW1hdGlvbjpmbG93IDVzIGxpbmVhciBpbmZpbml0ZX0KYnV0dG9ue3RyYW5zaXRpb246"
    "dHJhbnNmb3JtIC4xNXMsZmlsdGVyIC4xNXN9YnV0dG9uOmhvdmVyOm5vdCg6ZGlzYWJsZWQpe3RyYW5zZm9ybTp0cmFuc2xhdGVZ"
    "KC0xcHgpIHNjYWxlKDEuMDMpO2ZpbHRlcjpicmlnaHRuZXNzKDEuMSl9Ci5kb3R7YW5pbWF0aW9uOnB1bHNlIDEuNHMgZWFzZS1p"
    "bi1vdXQgaW5maW5pdGV9CkBrZXlmcmFtZXMgcHVsc2V7MCUsMTAwJXt0cmFuc2Zvcm06c2NhbGUoMSk7b3BhY2l0eToxfTUwJXt0"
    "cmFuc2Zvcm06c2NhbGUoMS41KTtvcGFjaXR5Oi42fX0KLnRhYnMgYnV0dG9uOm5vdCgub24pe2JhY2tncm91bmQ6dmFyKC0tY2Fy"
    "ZCk7YW5pbWF0aW9uOm5vbmV9CkBtZWRpYShwcmVmZXJzLXJlZHVjZWQtbW90aW9uOnJlZHVjZSl7KiwqOjpiZWZvcmV7YW5pbWF0"
    "aW9uOm5vbmUhaW1wb3J0YW50O3RyYW5zaXRpb246bm9uZSFpbXBvcnRhbnR9fQojcGd3e2hlaWdodDoxMHB4O2JvcmRlci1yYWRp"
    "dXM6NnB4O2JhY2tncm91bmQ6dmFyKC0tbGluZSk7b3ZlcmZsb3c6aGlkZGVuO21hcmdpbi10b3A6OHB4fSNwZ2J7aGVpZ2h0OjEw"
    "MCU7d2lkdGg6MDtiYWNrZ3JvdW5kOnZhcigtLWFjKTt0cmFuc2l0aW9uOndpZHRoIC4zc30KPC9zdHlsZT4KPC9oZWFkPgo8Ym9k"
    "eT4KPGRpdiBjbGFzcz0idyI+CiAgPGgxPvCfh6fwn4epIEFueSBwZW9wbGUgYmQgdm9pY2UgY2xvbmUgPHNwYW4gc3R5bGU9ImZv"
    "bnQtc2l6ZToxM3B4O2JhY2tncm91bmQ6dmFyKC0tYWMpO2NvbG9yOiMwNDI4MWQ7Ym9yZGVyLXJhZGl1czo4cHg7cGFkZGluZzoy"
    "cHggOHB4O3ZlcnRpY2FsLWFsaWduOm1pZGRsZSI+djI8L3NwYW4+PC9oMT4KICA8ZGl2IGNsYXNzPSJzdWIiPuCmieCmqOCnjeCm"
    "qOCmpCDgpqzgpr7gpoLgprLgpr4g4Kat4Kav4Ka84KeH4Ka4IOCmleCnjeCmsuCni+CmqOCmv+CmgiDCtyBHb29nbGUgQ29sYWIg"
    "4Kas4KeN4Kav4Ka+4KaV4KaP4Kao4KeN4KahIMK3IOCmtuCngeCmp+CngSDgpqjgpr/gppzgp4fgprAg4Kas4Ka+IOCmheCmqOCn"
    "geCmruCmpOCmv+CmquCnjeCmsOCmvuCmquCnjeCmpCDgppXgpqPgp43gpqA8L2Rpdj4KCiAgPGRpdiBjbGFzcz0iY2FyZCI+CiAg"
    "ICA8ZGl2IGNsYXNzPSJyb3ciPgogICAgICA8ZGl2PjxsYWJlbD5Db2xhYiDgprjgpr7gprDgp43gpq3gpr7gprAgVVJMPC9sYWJl"
    "bD48aW5wdXQgdHlwZT0idGV4dCIgaWQ9ImJhc2UiIHBsYWNlaG9sZGVyPSJodHRwczovL3h4eHgudHJ5Y2xvdWRmbGFyZS5jb20i"
    "PjwvZGl2PgogICAgICA8ZGl2PjxsYWJlbD7gpp/gp4vgppXgp4fgpqg8L2xhYmVsPjxpbnB1dCB0eXBlPSJwYXNzd29yZCIgaWQ9"
    "InRvayIgcGxhY2Vob2xkZXI9IkNvbGFiLeCmjyDgpqbgp4fgppbgpr7gpqjgp4sg4Kaf4KeL4KaV4KeH4KaoIj48L2Rpdj4KICAg"
    "ICAgPGJ1dHRvbiBpZD0iY29ubiIgc3R5bGU9ImFsaWduLXNlbGY6ZmxleC1lbmQiPuCmuOCmguCmr+Cni+CmlzwvYnV0dG9uPgog"
    "ICAgPC9kaXY+CiAgICA8ZGl2IGNsYXNzPSJtc2ciIGlkPSJzdCI+PHNwYW4gY2xhc3M9ImRvdCI+PC9zcGFuPuCmuOCmguCmr+Cn"
    "geCmleCnjeCmpCDgpqjgpq/gprw8L2Rpdj4KICA8L2Rpdj4KCiAgPGRpdiBjbGFzcz0idGFicyI+PGJ1dHRvbiBjbGFzcz0ib24i"
    "IGRhdGEtdD0iZ2VuIj7wn5SKIOCmnOCnh+CmqOCmvuCmsOCnh+CmnzwvYnV0dG9uPjxidXR0b24gZGF0YS10PSJ2b3giPvCfjqQg"
    "4Kat4Kav4Ka84KeH4Ka4PC9idXR0b24+PC9kaXY+CgogIDxkaXYgaWQ9InQtZ2VuIj4KICAgIDxkaXYgY2xhc3M9ImNhcmQiPgog"
    "ICAgICA8bGFiZWw+4Kat4Kav4Ka84KeH4Ka4PC9sYWJlbD48c2VsZWN0IGlkPSJndiI+PC9zZWxlY3Q+CiAgICAgIDxsYWJlbD7g"
    "pqzgpr7gpoLgprLgpr4g4Kaf4KeH4KaV4KeN4Ka44KafPC9sYWJlbD4KICAgICAgPHRleHRhcmVhIGlkPSJndCI+4KaG4KacIOCm"
    "huCmrOCmueCmvuCmk+Cmr+CmvOCmviDgppbgp4Hgpqwg4Ka44KeB4Kao4KeN4Kam4Kaw4KWkIOCmmuCmsuCniywg4KaP4KaV4Kaf"
    "4KeBIOCmueCnh+CmgeCmn+CnhyDgpobgprjgpr/gpaQ8L3RleHRhcmVhPgogICAgICA8ZGl2IGNsYXNzPSJ0ZyIgaWQ9InRhZ3Mi"
    "PjwvZGl2PgogICAgICA8ZGl2IGNsYXNzPSJyb3ciIHN0eWxlPSJtYXJnaW4tdG9wOjhweCI+PGRpdj48aW5wdXQgdHlwZT0iZmls"
    "ZSIgaWQ9InRmIiBhY2NlcHQ9Ii50eHQsdGV4dC9wbGFpbiI+PC9kaXY+PHNwYW4gY2xhc3M9Im1zZyIgaWQ9ImNjIiBzdHlsZT0i"
    "bWFyZ2luOjA7ZmxleDowIDAgYXV0byI+PC9zcGFuPjwvZGl2PgogICAgICA8ZGV0YWlscz48c3VtbWFyeT7gpongpqjgp43gpqjg"
    "pqQg4Ka44KeH4Kaf4Ka/4KaC4Ka4PC9zdW1tYXJ5PgogICAgICAgIDxkaXYgY2xhc3M9InJvdyI+CiAgICAgICAgICA8ZGl2Pjxs"
    "YWJlbD7gppfgpqTgpr8gPGIgaWQ9InN2Ij4xLjA8L2I+PC9sYWJlbD48aW5wdXQgdHlwZT0icmFuZ2UiIGlkPSJzcCIgbWluPSIw"
    "LjciIG1heD0iMS40IiBzdGVwPSIwLjA1IiB2YWx1ZT0iMSIgc3R5bGU9IndpZHRoOjEwMCUiPjwvZGl2PgogICAgICAgICAgPGRp"
    "dj48bGFiZWw+4KaV4KeL4Kav4Ka84Ka+4Kay4Ka/4Kaf4Ka/IOCmuOCnjeCmn+Cnh+CmqjwvbGFiZWw+PGlucHV0IHR5cGU9Im51"
    "bWJlciIgaWQ9InN0cCIgdmFsdWU9IjMyIiBtaW49IjgiIG1heD0iNjQiPjwvZGl2PgogICAgICAgICAgPGRpdj48bGFiZWw+QmVz"
    "dC1vZi1OPC9sYWJlbD48aW5wdXQgdHlwZT0ibnVtYmVyIiBpZD0iYm8iIHZhbHVlPSIzIiBtaW49IjEiIG1heD0iNiI+PC9kaXY+"
    "CiAgICAgICAgICA8ZGl2PjxsYWJlbD5HdWlkYW5jZTwvbGFiZWw+PGlucHV0IHR5cGU9Im51bWJlciIgaWQ9ImdkIiB2YWx1ZT0i"
    "MiIgc3RlcD0iMC4xIiBtaW49IjEiIG1heD0iNCI+PC9kaXY+CiAgICAgICAgICA8ZGl2PjxsYWJlbD5TZWVkICgtMSA9IOCmj+Cm"
    "suCni+CmruCnh+CmsuCniyk8L2xhYmVsPjxpbnB1dCB0eXBlPSJudW1iZXIiIGlkPSJzZCIgdmFsdWU9Ii0xIj48L2Rpdj4KICAg"
    "ICAgICA8L2Rpdj4KICAgICAgICA8ZGl2IGNsYXNzPSJyb3ciPjxkaXY+PGxhYmVsPuCmhuCmieCmn+CmquCngeCmnyDgpqvgprDg"
    "pq7gp43gpq/gpr7gpp88L2xhYmVsPjxzZWxlY3QgaWQ9ImZtIj48b3B0aW9uIHZhbHVlPSJ3YXYiPldBViAo4Ka44KeH4Kaw4Ka+"
    "IOCmruCmvuCmqCk8L29wdGlvbj48b3B0aW9uIHZhbHVlPSJtcDMiPk1QMyAo4Kab4KeL4KafIOCmq+CmvuCmh+Cmsik8L29wdGlv"
    "bj48L3NlbGVjdD48L2Rpdj48L2Rpdj4KICAgICAgICA8bGFiZWw+4KaJ4Kaa4KeN4Kaa4Ka+4Kaw4KajIOCmheCmreCmv+Cmp+Cm"
    "vuCmqCDigJQg4Kaq4KeN4Kaw4Kak4Ka/IOCmsuCmvuCmh+CmqOCnhyA8Y29kZT7gprbgpqzgp43gpqY94Kav4KeH4Kat4Ka+4Kas"
    "4KeHIOCmquCmoeCmvOCmrOCnhzwvY29kZT48L2xhYmVsPgogICAgICAgIDx0ZXh0YXJlYSBpZD0ibHgiIHN0eWxlPSJtaW4taGVp"
    "Z2h0OjcwcHgiIHBsYWNlaG9sZGVyPSJXaS1GaT3gppPgpq/gprzgpr7gpofgpqvgpr7gpocmIzEwO1pvb2094Kac4KeB4KauIj48"
    "L3RleHRhcmVhPgogICAgICAgIDxkaXYgY2xhc3M9ImNoayI+PGlucHV0IHR5cGU9ImNoZWNrYm94IiBpZD0ibm0iIGNoZWNrZWQ+"
    "PHNwYW4+4Kas4Ka+4KaC4Kay4Ka+IOCmqOCmsOCmruCmvuCmsuCmvuCmh+CmnOCnh+CmtuCmqCAo4Ka44KaC4KaW4KeN4Kav4Ka+"
    "L+CmpOCmvuCmsOCmv+Cmli/gpp/gpr7gppXgpr4g4Kaq4Kah4Ka84Ka+4KawIOCmieCmquCmr+Cni+Cml+CngCDgppXgprDgpr4p"
    "PC9zcGFuPjwvZGl2PgogICAgICA8L2RldGFpbHM+CiAgICAgIDxkaXYgY2xhc3M9InJvdyIgc3R5bGU9Im1hcmdpbi10b3A6MTRw"
    "eCI+PGJ1dHRvbiBpZD0iZ28iPuCmnOCnh+CmqOCmvuCmsOCnh+CmnzwvYnV0dG9uPjxidXR0b24gY2xhc3M9InNlYyIgaWQ9InJm"
    "Ij7gpq3gpq/gprzgp4fgprgg4Kaw4Ka/4Kar4KeN4Kaw4KeH4Ka2PC9idXR0b24+PC9kaXY+CiAgICAgIDxkaXYgY2xhc3M9Im1z"
    "ZyIgaWQ9ImdtIj48L2Rpdj4KICAgICAgPGRpdiBpZD0icGd3IiBjbGFzcz0iaGlkZSI+PGRpdiBpZD0icGdiIj48L2Rpdj48L2Rp"
    "dj4KICAgICAgPGF1ZGlvIGlkPSJhbyIgY29udHJvbHMgY2xhc3M9ImhpZGUiPjwvYXVkaW8+CiAgICAgIDxhIGlkPSJkbCIgY2xh"
    "c3M9ImhpZGUiIGRvd25sb2FkPSJiYW5nbGFfdm9pY2Uud2F2Ij48YnV0dG9uIGNsYXNzPSJzZWMiIHN0eWxlPSJtYXJnaW4tdG9w"
    "OjEwcHgiPuKshyBXQVYg4Kah4Ka+4KaJ4Kao4Kay4KeL4KahPC9idXR0b24+PC9hPgogICAgPC9kaXY+CiAgPGRpdiBjbGFzcz0i"
    "Y2FyZCIgaWQ9ImhjIj48Yj7gpo/gpocg4Ka44KeH4Ka24Kao4KeH4KawIOCmnOCnh+CmqOCmvuCmsOCnh+CmtuCmqDwvYj48ZGl2"
    "IGlkPSJobCI+PC9kaXY+PC9kaXY+CiAgPC9kaXY+CgogICAgPGRpdiBpZD0idC12b3giIGNsYXNzPSJoaWRlIj4KICAgIDxkaXYg"
    "Y2xhc3M9ImNhcmQiPgogICAgICA8bGFiZWw+4Kat4Kav4Ka84KeH4Ka44KeH4KawIOCmqOCmvuCmrjwvbGFiZWw+PGlucHV0IHR5"
    "cGU9InRleHQiIGlkPSJ2biIgcGxhY2Vob2xkZXI9IuCmr+Cnh+CmruCmqDogcmFoaW0iPgogICAgICA8bGFiZWw+4Kaw4KeH4Kar"
    "4Ka+4Kaw4KeH4Kao4KeN4Ka4IOCmheCmoeCmv+CmkyAo4Ker4oCT4Ken4KerIOCmuOCnh+CmleCnh+CmqOCnjeCmoSwg4Kaq4Kaw"
    "4Ka/4Ka34KeN4KaV4Ka+4KawLCDgpo/gppXgppzgpqjgp4fgprAg4KaV4Kal4Ka+KTwvbGFiZWw+CiAgICAgIDxpbnB1dCB0eXBl"
    "PSJmaWxlIiBpZD0idmYiIGFjY2VwdD0iYXVkaW8vKiI+CiAgICAgIDxkaXYgY2xhc3M9InJvdyIgc3R5bGU9Im1hcmdpbi10b3A6"
    "OHB4Ij48YnV0dG9uIGNsYXNzPSJzZWMiIGlkPSJyZWMiPvCfjpkg4Kau4Ka+4KaH4KaV4KeHIOCmsOCnh+CmleCmsOCnjeCmoTwv"
    "YnV0dG9uPjxzcGFuIGNsYXNzPSJtc2ciIGlkPSJycyIgc3R5bGU9Im1hcmdpbjowIj48L3NwYW4+PC9kaXY+CiAgICAgIDxhdWRp"
    "byBpZD0idnAiIGNvbnRyb2xzIGNsYXNzPSJoaWRlIj48L2F1ZGlvPgogICAgICA8bGFiZWw+4Kaw4KeH4Kar4Ka+4Kaw4KeH4Kao"
    "4KeN4Ka44KeH4KawIOCmn+CnjeCmsOCmvuCmqOCnjeCmuOCmleCnjeCmsOCmv+CmquCnjeCmnyAo4Kar4Ka+4KaB4KaV4Ka+IOCm"
    "sOCmvuCmluCmsuCnhyDgprjgp43gpqzgpq/gprzgpoLgppXgp43gprDgpr/gpq/gprwgwrcg4Kat4KeB4KayIOCmpeCmvuCmleCm"
    "suCnhyDgpqDgpr/gppUg4KaV4Kaw4KeB4KaoKTwvbGFiZWw+CiAgICAgIDx0ZXh0YXJlYSBpZD0idnQiIHN0eWxlPSJtaW4taGVp"
    "Z2h0OjgwcHgiPjwvdGV4dGFyZWE+CiAgICAgIDxkaXYgY2xhc3M9InJvdyI+PGxhYmVsIGNsYXNzPSJjaGsiIHN0eWxlPSJtYXJn"
    "aW46MCI+PGlucHV0IHR5cGU9ImNoZWNrYm94IiBpZD0iZG4iIGNoZWNrZWQ+4Kao4Kav4Ka84KeH4KacIOCmsOCmv+CmruCngeCm"
    "rTwvbGFiZWw+PGxhYmVsIGNsYXNzPSJjaGsiIHN0eWxlPSJtYXJnaW46MCI+PGlucHV0IHR5cGU9ImNoZWNrYm94IiBpZD0icGsi"
    "IGNoZWNrZWQ+4Ka44KeH4Kaw4Ka+IOCmheCmguCmtiDgpqzgpr7gppvgpr7gpoc8L2xhYmVsPjwvZGl2PgogICAgICA8bGFiZWwg"
    "Y2xhc3M9ImNoayI+PGlucHV0IHR5cGU9ImNoZWNrYm94IiBpZD0iY3MiPjxzcGFuPuCmhuCmruCmvyDgpqjgpr/gprbgp43gpprg"
    "pr/gpqQg4KaV4Kaw4Kab4Ka/OiDgpo/gpp/gpr8g4KaG4Kau4Ka+4KawIOCmqOCmv+CmnOCnh+CmsCDgppXgpqPgp43gpqAsIOCm"
    "heCmpeCmrOCmviDgppXgpqPgp43gpqDgpqfgpr7gprDgp4DgprAg4Ka44KeN4Kaq4Ka34KeN4KafIOCmheCmqOCngeCmruCmpOCm"
    "vyDgpobgppvgp4fgpaQ8L3NwYW4+PC9sYWJlbD4KICAgICAgPGRpdiBjbGFzcz0icm93IiBzdHlsZT0ibWFyZ2luLXRvcDoxNHB4"
    "Ij48YnV0dG9uIGNsYXNzPSJzZWMiIGlkPSJ0ciI+4Kaf4KeN4Kaw4Ka+4Kao4KeN4Ka44KaV4KeN4Kaw4Ka+4KaH4KasPC9idXR0"
    "b24+PGJ1dHRvbiBpZD0ic3YyIj7gpq3gpq/gprzgp4fgprgg4Ka44KeH4KatIOCmleCmsOCngeCmqDwvYnV0dG9uPjwvZGl2Pgog"
    "ICAgICA8ZGl2IGNsYXNzPSJtc2ciIGlkPSJ2bSI+PC9kaXY+CiAgICA8L2Rpdj4KICAgIDxkaXYgY2xhc3M9ImNhcmQiPjxiPuCm"
    "uOCmguCmsOCmleCnjeCmt+Cmv+CmpCDgpq3gpq/gprzgp4fgprg8L2I+PGRpdiBpZD0idmwiIHN0eWxlPSJtYXJnaW4tdG9wOjZw"
    "eCI+PC9kaXY+PC9kaXY+CiAgPC9kaXY+CjwvZGl2PgoKPHNjcmlwdD4KY29uc3QgJD1pZD0+ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5"
    "SWQoaWQpOwpjb25zdCBzdG9yZT0oayx2KT0+e3RyeXtpZih2PT09dW5kZWZpbmVkKXJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRl"
    "bShrKXx8IiI7bG9jYWxTdG9yYWdlLnNldEl0ZW0oayx2KX1jYXRjaChlKXtyZXR1cm4gIiJ9fTsKbGV0IEJBU0U9IiIsVE9LPSIi"
    "LHJlYz1udWxsLHJlY0Jsb2I9bnVsbDsKCi8vIOCmtuCngeCmsOCngeCmpOCnhzogVVJMIOCmueCnjeCmr+CmvuCmtiAoI3Rva2Vu"
    "PS4uKSDgpqzgpr4g4Ka44Ka+4Kaw4KeN4Kat4Ka+4KawIOCmpeCnh+CmleCnhyDgppbgp4vgprLgpr4g4Ka54Kay4KeHIOCmqOCm"
    "v+CmnOCnh+CmsCBvcmlnaW4KY29uc3QgaHA9bmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5oYXNoLnNsaWNlKDEpKTsKJCgi"
    "YmFzZSIpLnZhbHVlPS9eaHR0cHM/Oi8udGVzdChsb2NhdGlvbi5vcmlnaW4pP2xvY2F0aW9uLm9yaWdpbjpzdG9yZSgiYmFzZSIp"
    "OwokKCJ0b2siKS52YWx1ZT1ocC5nZXQoInRva2VuIil8fHN0b3JlKCJ0b2siKTsKCmZ1bmN0aW9uIHN0YXR1cyhvayx0KXskKCJz"
    "dCIpLmlubmVySFRNTD0nPHNwYW4gY2xhc3M9ImRvdCcrKG9rPycgb2snOicnKSsnIj48L3NwYW4+Jyt0fQpmdW5jdGlvbiBzYXko"
    "aWQsdCxlcnIpe2NvbnN0IGU9JChpZCk7ZS50ZXh0Q29udGVudD10O2UuY2xhc3NOYW1lPSJtc2ciKyhlcnI/IiBlcnIiOiIiKX0K"
    "YXN5bmMgZnVuY3Rpb24gYXBpKHBhdGgsb3B0PXt9KXsKICBvcHQuaGVhZGVycz1PYmplY3QuYXNzaWduKHsiWC1Ub2tlbiI6VE9L"
    "fSxvcHQuaGVhZGVyc3x8e30pOwogIGNvbnN0IHI9YXdhaXQgZmV0Y2goQkFTRStwYXRoLG9wdCk7CiAgaWYoIXIub2spe2xldCBt"
    "PXIuc3RhdHVzKyIiO3RyeXttPShhd2FpdCByLmpzb24oKSkuZGV0YWlsfHxtfWNhdGNoKGUpe310aHJvdyBuZXcgRXJyb3IobSl9"
    "CiAgcmV0dXJuIHI7Cn0KYXN5bmMgZnVuY3Rpb24gY29ubmVjdCgpewogIEJBU0U9JCgiYmFzZSIpLnZhbHVlLnRyaW0oKS5yZXBs"
    "YWNlKC9cLyskLywiIik7VE9LPSQoInRvayIpLnZhbHVlLnRyaW0oKTsKICBpZighQkFTRSl7c3RhdHVzKGZhbHNlLCJVUkwg4Kam"
    "4Ka/4KaoIik7cmV0dXJufQogIHRyeXsKICAgIGNvbnN0IGg9YXdhaXQgKGF3YWl0IGFwaSgiL2FwaS9oZWFsdGgiKSkuanNvbigp"
    "OwogICAgc3RvcmUoImJhc2UiLEJBU0UpO3N0b3JlKCJ0b2siLFRPSyk7c3RhdHVzKHRydWUsIuCmuOCmguCmr+CngeCmleCnjeCm"
    "pCDCtyAiK2guZ3B1KyIgwrcg4Kat4Kav4Ka84KeH4Ka4OiAiK2gudm9pY2VzKTsKICAgIGF3YWl0IGxvYWRWb2ljZXMoKTsKICB9"
    "Y2F0Y2goZSl7c3RhdHVzKGZhbHNlLCLgprjgpoLgpq/gp4vgppcg4Kas4KeN4Kav4Kaw4KeN4KalOiAiK2UubWVzc2FnZSl9Cn0K"
    "YXN5bmMgZnVuY3Rpb24gbG9hZFZvaWNlcygpewogIGNvbnN0IGxpc3Q9YXdhaXQgKGF3YWl0IGFwaSgiL2FwaS92b2ljZXMiKSku"
    "anNvbigpOwogIGNvbnN0IGN1cj0kKCJndiIpLnZhbHVlOwogICQoImd2IikuaW5uZXJIVE1MPWxpc3QubWFwKHY9PmA8b3B0aW9u"
    "IHZhbHVlPSIke3YuaWR9Ij4ke3YubmFtZX08L29wdGlvbj5gKS5qb2luKCIiKXx8JzxvcHRpb24gdmFsdWU9IiI+4oCUIOCmhuCm"
    "l+CnhyDgpq3gpq/gprzgp4fgprgg4Kak4KeI4Kaw4Ka/IOCmleCmsOCngeCmqCDigJQ8L29wdGlvbj4nOwogIGlmKGN1cikkKCJn"
    "diIpLnZhbHVlPWN1cjsKICAkKCJ2bCIpLmlubmVySFRNTD1saXN0Lm1hcCh2PT5gPGRpdiBjbGFzcz0idiI+PGRpdj48Yj4ke3Yu"
    "bmFtZX08L2I+PHNtYWxsPiR7KHYucXVhbGl0eSYmdi5xdWFsaXR5Lm5vdGVzfHxbXSkuam9pbigiICIpfTwvc21hbGw+PHNtYWxs"
    "PiR7di5yZWZfdGV4dHx8IiJ9PC9zbWFsbD48L2Rpdj4KICAgIDxkaXYgY2xhc3M9InJvdyIgc3R5bGU9ImZsZXg6MCAwIGF1dG8i"
    "PjxidXR0b24gY2xhc3M9InNlYyIgb25jbGljaz0icGxheVJlZignJHt2LmlkfScpIj7ilrY8L2J1dHRvbj48YnV0dG9uIGNsYXNz"
    "PSJkbmciIG9uY2xpY2s9ImRlbFYoJyR7di5pZH0nKSI+4Kau4KeB4Kab4KeB4KaoPC9idXR0b24+PC9kaXY+PC9kaXY+YCkuam9p"
    "bigiIil8fCc8c21hbGwgc3R5bGU9ImNvbG9yOnZhcigtLW11dCkiPuCmleCni+CmqOCniyDgpq3gpq/gprzgp4fgprgg4Kao4KeH"
    "4KaHPC9zbWFsbD4nOwp9CmFzeW5jIGZ1bmN0aW9uIHBsYXlSZWYoaWQpewogIGNvbnN0IGI9YXdhaXQgKGF3YWl0IGFwaSgiL2Fw"
    "aS92b2ljZXMvIitpZCsiL3JlZiIpKS5ibG9iKCk7CiAgY29uc3QgYT0kKCJ2cCIpO2Euc3JjPVVSTC5jcmVhdGVPYmplY3RVUkwo"
    "Yik7YS5jbGFzc0xpc3QucmVtb3ZlKCJoaWRlIik7YS5wbGF5KCk7Cn0KYXN5bmMgZnVuY3Rpb24gZGVsVihpZCl7aWYoIWNvbmZp"
    "cm0oIuCmruCngeCmm+CnhyDgpqvgp4fgprLgpqzgp4fgpqg/IikpcmV0dXJuO2F3YWl0IGFwaSgiL2FwaS92b2ljZXMvIitpZCx7"
    "bWV0aG9kOiJERUxFVEUifSk7bG9hZFZvaWNlcygpfQoKLy8g4Kaw4KeH4KaV4Kaw4KeN4Kah4Ka/4KaCCiQoInJlYyIpLm9uY2xp"
    "Y2s9YXN5bmMoKT0+ewogIGlmKHJlYyl7cmVjLnN0b3AoKTtyZXR1cm59CiAgdHJ5ewogICAgY29uc3Qgcz1hd2FpdCBuYXZpZ2F0"
    "b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYSh7YXVkaW86e2VjaG9DYW5jZWxsYXRpb246ZmFsc2Usbm9pc2VTdXBwcmVzc2lv"
    "bjp0cnVlfX0pOwogICAgY29uc3QgY2g9W107cmVjPW5ldyBNZWRpYVJlY29yZGVyKHMpOwogICAgcmVjLm9uZGF0YWF2YWlsYWJs"
    "ZT1lPT5jaC5wdXNoKGUuZGF0YSk7CiAgICByZWMub25zdG9wPSgpPT57cy5nZXRUcmFja3MoKS5mb3JFYWNoKHQ9PnQuc3RvcCgp"
    "KTtyZWNCbG9iPW5ldyBCbG9iKGNoLHt0eXBlOnJlYy5taW1lVHlwZX0pO3JlYz1udWxsOwogICAgICAkKCJyZWMiKS50ZXh0Q29u"
    "dGVudD0i8J+OmSDgpq7gpr7gpofgppXgp4cg4Kaw4KeH4KaV4Kaw4KeN4KahIjtzYXkoInJzIiwi4Kaw4KeH4KaV4Kaw4KeN4Kah"
    "IOCmueCmr+CmvOCnh+Cmm+CnhyDinJQiKTskKCJ2ZiIpLnZhbHVlPSIiOwogICAgICBjb25zdCBhPSQoInZwIik7YS5zcmM9VVJM"
    "LmNyZWF0ZU9iamVjdFVSTChyZWNCbG9iKTthLmNsYXNzTGlzdC5yZW1vdmUoImhpZGUiKX07CiAgICByZWMuc3RhcnQoKTskKCJy"
    "ZWMiKS50ZXh0Q29udGVudD0i4o+5IOCmpeCmvuCmruCmvuCmqCI7c2F5KCJycyIsIuCmsOCnh+CmleCmsOCnjeCmoSDgprngpprg"
    "p43gppvgp4figKYg4Ker4oCT4Ken4KemIOCmuOCnh+CmleCnh+CmqOCnjeCmoSDgprjgp43gpqzgpr7gpq3gpr7gpqzgpr/gppXg"
    "pq3gpr7gpqzgp4cg4Kaq4Kah4Ka84KeB4KaoIik7CiAgfWNhdGNoKGUpe3NheSgicnMiLCLgpq7gpr7gpofgppUg4KaF4Kao4KeB"
    "4Kau4Kak4Ka/IOCmquCmvuCmk+Cmr+CmvOCmviDgpq/gpr7gpq/gprzgpqjgpr8gKEhUVFBTIOCmsuCmv+CmguCmlSDgpqzgpr4g"
    "4KaF4Kao4KeB4Kau4Kak4Ka/IOCmpuCmsOCmleCmvuCmsCkiLDEpfQp9OwpmdW5jdGlvbiByZWZGaWxlKCl7CiAgaWYoJCgidmYi"
    "KS5maWxlc1swXSl7cmVjQmxvYj1udWxsO3JldHVybiAkKCJ2ZiIpLmZpbGVzWzBdfQogIGlmKHJlY0Jsb2IpcmV0dXJuIG5ldyBG"
    "aWxlKFtyZWNCbG9iXSwicmVjLiIrKHJlY0Jsb2IudHlwZS5pbmNsdWRlcygib2dnIik/Im9nZyI6IndlYm0iKSk7CiAgcmV0dXJu"
    "IG51bGw7Cn0KJCgidmYiKS5vbmNoYW5nZT0oKT0+e2NvbnN0IGY9JCgidmYiKS5maWxlc1swXTtpZihmKXtyZWNCbG9iPW51bGw7"
    "Y29uc3QgYT0kKCJ2cCIpO2Euc3JjPVVSTC5jcmVhdGVPYmplY3RVUkwoZik7YS5jbGFzc0xpc3QucmVtb3ZlKCJoaWRlIil9fTsK"
    "CiQoInRyIikub25jbGljaz1hc3luYygpPT57CiAgY29uc3QgZj1yZWZGaWxlKCk7aWYoIWYpcmV0dXJuIHNheSgidm0iLCLgpobg"
    "ppfgp4cg4KaF4Kah4Ka/4KaTIOCmpuCmv+CmqCIsMSk7CiAgJCgidHIiKS5kaXNhYmxlZD10cnVlO3NheSgidm0iLCLgpp/gp43g"
    "prDgpr7gpqjgp43gprjgppXgp43gprDgpr7gpofgpqwg4Ka54Kaa4KeN4Kab4KeH4oCmIik7CiAgdHJ5e2NvbnN0IGZkPW5ldyBG"
    "b3JtRGF0YSgpO2ZkLmFwcGVuZCgiZmlsZSIsZik7ZmQuYXBwZW5kKCJkZW5vaXNlIiwkKCJkbiIpLmNoZWNrZWQpO2ZkLmFwcGVu"
    "ZCgicGlja19iZXN0IiwkKCJwayIpLmNoZWNrZWQpOwogICAgY29uc3Qgaj1hd2FpdCAoYXdhaXQgYXBpKCIvYXBpL3RyYW5zY3Jp"
    "YmUiLHttZXRob2Q6IlBPU1QiLGJvZHk6ZmR9KSkuanNvbigpOwogICAgJCgidnQiKS52YWx1ZT1qLnRleHQ7c2F5KCJ2bSIsKGou"
    "cXVhbGl0eXx8W10pLmpvaW4oIlxuIikrIlxu4Kag4Ka/4KaVIOCmhuCmm+CnhyDgppXgpr/gpqjgpr4g4Kam4KeH4KaW4KeHIOCm"
    "reCngeCmsiDgpqXgpr7gppXgprLgp4cg4Ka44KaC4Ka24KeL4Kan4KaoIOCmleCmsOCngeCmqOClpCIpfQogIGNhdGNoKGUpe3Nh"
    "eSgidm0iLGUubWVzc2FnZSwxKX0kKCJ0ciIpLmRpc2FibGVkPWZhbHNlOwp9OwokKCJzdjIiKS5vbmNsaWNrPWFzeW5jKCk9PnsK"
    "ICBjb25zdCBmPXJlZkZpbGUoKSxuPSQoInZuIikudmFsdWUudHJpbSgpOwogIGlmKCFufHwhZilyZXR1cm4gc2F5KCJ2bSIsIuCm"
    "qOCmvuCmriDgppMg4KaF4Kah4Ka/4KaTIOCmpuCmv+CmqCIsMSk7CiAgaWYoISQoImNzIikuY2hlY2tlZClyZXR1cm4gc2F5KCJ2"
    "bSIsIuCmuOCmruCnjeCmruCmpOCmvyDgpprgp4fgppXgpqzgppXgp43gprgg4Kao4Ka/4Ka24KeN4Kaa4Ka/4KakIOCmleCmsOCn"
    "geCmqCIsMSk7CiAgJCgic3YyIikuZGlzYWJsZWQ9dHJ1ZTtzYXkoInZtIiwi4Kat4Kav4Ka84KeH4Ka4IOCmpOCniOCmsOCmvyDg"
    "prngpprgp43gppvgp4figKYiKTsKICB0cnl7Y29uc3QgZmQ9bmV3IEZvcm1EYXRhKCk7ZmQuYXBwZW5kKCJmaWxlIixmKTtmZC5h"
    "cHBlbmQoIm5hbWUiLG4pO2ZkLmFwcGVuZCgicmVmX3RleHQiLCQoInZ0IikudmFsdWUpOwogICAgZmQuYXBwZW5kKCJjb25zZW50"
    "Iix0cnVlKTtmZC5hcHBlbmQoImRlbm9pc2UiLCQoImRuIikuY2hlY2tlZCk7ZmQuYXBwZW5kKCJwaWNrX2Jlc3QiLCQoInBrIiku"
    "Y2hlY2tlZCk7CiAgICBjb25zdCBqPWF3YWl0IChhd2FpdCBhcGkoIi9hcGkvdm9pY2VzIix7bWV0aG9kOiJQT1NUIixib2R5OmZk"
    "fSkpLmpzb24oKTsKICAgIHNheSgidm0iLCLinIUg4Ka44KeH4KatIOCmueCmr+CmvOCnh+Cmm+CnhzogIitqLm5hbWUrIlxuIiso"
    "ai5xdWFsaXR5Lm5vdGVzfHxbXSkuam9pbigiXG4iKSk7YXdhaXQgbG9hZFZvaWNlcygpOyQoImd2IikudmFsdWU9ai5pZH0KICBj"
    "YXRjaChlKXtzYXkoInZtIixlLm1lc3NhZ2UsMSl9JCgic3YyIikuZGlzYWJsZWQ9ZmFsc2U7Cn07CgovLyDgppzgp4fgpqjgpr7g"
    "prDgp4fgpp8KJCgic3AiKS5vbmlucHV0PSgpPT4kKCJzdiIpLnRleHRDb250ZW50PSgrJCgic3AiKS52YWx1ZSkudG9GaXhlZCgy"
    "KTsKJCgiZ28iKS5vbmNsaWNrPWFzeW5jKCk9PnsKICBpZighJCgiZ3YiKS52YWx1ZSlyZXR1cm4gc2F5KCJnbSIsIuCmhuCml+Cn"
    "hyDgpq3gpq/gprzgp4fgprgg4Kas4KeH4Kab4KeHIOCmqOCmv+CmqCIsMSk7CiAgJCgiZ28iKS5kaXNhYmxlZD10cnVlO3NheSgi"
    "Z20iLCLgppzgp4fgpqjgpr7gprDgp4fgpp8g4Ka54Kaa4KeN4Kab4KeH4oCmICjgpqzgpqHgprwg4Kay4KeH4KaW4Ka+4Kav4Ka8"
    "IOCmkyBCZXN0LW9mLU4g4Kas4KeH4Ka24Ka/IOCmueCmsuCnhyDgprjgpq7gpq/gprwg4Kay4Ka+4KaX4KeHKSIpOwogIGNvbnN0"
    "IHQwPXBlcmZvcm1hbmNlLm5vdygpOwogICQoInBndyIpLmNsYXNzTGlzdC5yZW1vdmUoImhpZGUiKTskKCJwZ2IiKS5zdHlsZS53"
    "aWR0aD0iMCUiOwogIGNvbnN0IHBvbGxUPXNldEludGVydmFsKGFzeW5jKCk9Pnt0cnl7Y29uc3QgcD1hd2FpdCAoYXdhaXQgYXBp"
    "KCIvYXBpL3Byb2dyZXNzIikpLmpzb24oKTsKICAgIGlmKHAuYWN0aXZlfHxwLnBjdCl7JCgicGdiIikuc3R5bGUud2lkdGg9cC5w"
    "Y3QrIiUiO3NheSgiZ20iLCLij7Mg4Kac4KeH4Kao4Ka+4Kaw4KeH4KafIOCmueCmmuCnjeCmm+Cnh+KApiAiK3AucGN0KyIlIOKA"
    "lCAiKyhwLmRlc2N8fCIiKSl9fWNhdGNoKGUpe319LDQwMCk7CiAgdHJ5ewogICAgY29uc3Qgcj1hd2FpdCBhcGkoIi9hcGkvdHRz"
    "Iix7bWV0aG9kOiJQT1NUIixoZWFkZXJzOnsiQ29udGVudC1UeXBlIjoiYXBwbGljYXRpb24vanNvbiJ9LGJvZHk6SlNPTi5zdHJp"
    "bmdpZnkoewogICAgICB2b2ljZTokKCJndiIpLnZhbHVlLHRleHQ6JCgiZ3QiKS52YWx1ZSxzcGVlZDorJCgic3AiKS52YWx1ZSxz"
    "dGVwczorJCgic3RwIikudmFsdWUsZ3VpZGFuY2U6KyQoImdkIikudmFsdWUsCiAgICAgIGJlc3Rfb2Y6KyQoImJvIikudmFsdWUs"
    "c2VlZDorJCgic2QiKS52YWx1ZSxub3JtYWxpemU6JCgibm0iKS5jaGVja2VkLGZtdDokKCJmbSIpLnZhbHVlLGxleGljb246bGV4"
    "T2JqKCl9KX0pOwogICAgY29uc3QgcmVwPWRlY29kZVVSSUNvbXBvbmVudChyLmhlYWRlcnMuZ2V0KCJYLVJlcG9ydCIpfHwiIik7"
    "CiAgICBjb25zdCBiPWF3YWl0IHIuYmxvYigpLHU9VVJMLmNyZWF0ZU9iamVjdFVSTChiKTsKICAgICQoImFvIikuc3JjPXU7JCgi"
    "YW8iKS5jbGFzc0xpc3QucmVtb3ZlKCJoaWRlIik7JCgiYW8iKS5wbGF5KCk7JCgiZGwiKS5ocmVmPXU7JCgiZGwiKS5kb3dubG9h"
    "ZD0iYmFuZ2xhX3ZvaWNlLiIrJCgiZm0iKS52YWx1ZTskKCJkbCIpLmNsYXNzTGlzdC5yZW1vdmUoImhpZGUiKTthZGRIaXN0KHUs"
    "JCgiZ3QiKS52YWx1ZS5zbGljZSgwLDYwKSwkKCJmbSIpLnZhbHVlKTsKICAgIGNsZWFySW50ZXJ2YWwocG9sbFQpOyQoInBnYiIp"
    "LnN0eWxlLndpZHRoPSIxMDAlIjtzZXRUaW1lb3V0KCgpPT4kKCJwZ3ciKS5jbGFzc0xpc3QuYWRkKCJoaWRlIiksMTIwMCk7CiAg"
    "ICBzYXkoImdtIiwi4pyFIOCnp+CnpuCnpiUg4oCUICIrKHJlcHx8KCLgprjgpq7gp43gpqrgpqjgp43gpqggwrcgIisoKHBlcmZv"
    "cm1hbmNlLm5vdygpLXQwKS8xMDAwKS50b0ZpeGVkKDEpKyJzIikpKTsKICB9Y2F0Y2goZSl7Y2xlYXJJbnRlcnZhbChwb2xsVCk7"
    "JCgicGd3IikuY2xhc3NMaXN0LmFkZCgiaGlkZSIpO3NheSgiZ20iLGUubWVzc2FnZSwxKX0kKCJnbyIpLmRpc2FibGVkPWZhbHNl"
    "Owp9OwovLyB2Mjog4Kao4KaoLeCmreCmvuCmsOCmrOCmvuCmsiDgpp/gp43gpq/gpr7gppcsIC50eHQg4KaG4Kaq4Kay4KeL4Kah"
    "LCDgpoXgpq3gpr/gpqfgpr7gpqgsIOCmueCmv+CmuOCnjeCmn+CnjeCmsOCmvwpbIltsYXVnaHRlcl0iLCJbc2lnaF0iLCJbcXVl"
    "c3Rpb24tYWhdIiwiW3N1cnByaXNlLWFoXSIsIltjb25maXJtYXRpb24tZW5dIl0uZm9yRWFjaCh0PT57CiAgY29uc3QgYj1kb2N1"
    "bWVudC5jcmVhdGVFbGVtZW50KCJidXR0b24iKTtiLmNsYXNzTmFtZT0ic2VjIjtiLnRleHRDb250ZW50PXQ7CiAgYi5vbmNsaWNr"
    "PSgpPT57Y29uc3QgYT0kKCJndCIpLHM9YS5zZWxlY3Rpb25TdGFydDthLnZhbHVlPWEudmFsdWUuc2xpY2UoMCxzKSt0KyIgIith"
    "LnZhbHVlLnNsaWNlKGEuc2VsZWN0aW9uRW5kKTthLmZvY3VzKCk7Y250KCl9OyQoInRhZ3MiKS5hcHBlbmRDaGlsZChiKX0pOwpj"
    "b25zdCBjbnQ9KCk9PiQoImNjIikudGV4dENvbnRlbnQ9JCgiZ3QiKS52YWx1ZS5sZW5ndGgrIiDgpoXgppXgp43gprfgprAiOyQo"
    "Imd0Iikub25pbnB1dD1jbnQ7Y250KCk7CiQoInRmIikub25jaGFuZ2U9YXN5bmMoKT0+e2NvbnN0IGY9JCgidGYiKS5maWxlc1sw"
    "XTtpZihmKXskKCJndCIpLnZhbHVlPWF3YWl0IGYudGV4dCgpO2NudCgpfX07CiQoImx4IikudmFsdWU9c3RvcmUoImx4Iik7JCgi"
    "bHgiKS5vbmNoYW5nZT0oKT0+c3RvcmUoImx4IiwkKCJseCIpLnZhbHVlKTsKY29uc3QgbGV4T2JqPSgpPT5PYmplY3QuZnJvbUVu"
    "dHJpZXMoJCgibHgiKS52YWx1ZS5zcGxpdCgiXG4iKS5tYXAobD0+bC5zcGxpdCgiPSIpKS5maWx0ZXIocD0+cC5sZW5ndGg+PTIm"
    "JnBbMF0udHJpbSgpKS5tYXAocD0+W3BbMF0udHJpbSgpLHAuc2xpY2UoMSkuam9pbigiPSIpLnRyaW0oKV0pKTsKY29uc3QgSElT"
    "VD1bXTsKZnVuY3Rpb24gYWRkSGlzdCh1cmwsdHh0LGZtdCl7SElTVC51bnNoaWZ0KHt1cmwsdHh0LGZtdH0pOwogICQoImhsIiku"
    "aW5uZXJIVE1MPUhJU1QubWFwKChoLGkpPT5gPGRpdiBjbGFzcz0iaCI+PHNwYW4+JHtoLnR4dC5yZXBsYWNlKC88L2csIiZsdDsi"
    "KX08L3NwYW4+PGJ1dHRvbiBjbGFzcz0ic2VjIiBvbmNsaWNrPSJuZXcgQXVkaW8oSElTVFske2l9XS51cmwpLnBsYXkoKSI+4pa2"
    "PC9idXR0b24+PGEgZG93bmxvYWQ9InZvaWNlXyR7SElTVC5sZW5ndGgtaX0uJHtoLmZtdH0iIGhyZWY9IiR7aC51cmx9Ij48YnV0"
    "dG9uIGNsYXNzPSJzZWMiPuKshzwvYnV0dG9uPjwvYT48L2Rpdj5gKS5qb2luKCIiKX0KJCgicmYiKS5vbmNsaWNrPSgpPT5sb2Fk"
    "Vm9pY2VzKCkuY2F0Y2goZT0+c2F5KCJnbSIsZS5tZXNzYWdlLDEpKTsKJCgiY29ubiIpLm9uY2xpY2s9Y29ubmVjdDsKCmRvY3Vt"
    "ZW50LnF1ZXJ5U2VsZWN0b3JBbGwoIi50YWJzIGJ1dHRvbiIpLmZvckVhY2goYj0+Yi5vbmNsaWNrPSgpPT57CiAgZG9jdW1lbnQu"
    "cXVlcnlTZWxlY3RvckFsbCgiLnRhYnMgYnV0dG9uIikuZm9yRWFjaCh4PT54LmNsYXNzTGlzdC50b2dnbGUoIm9uIix4PT09Yikp"
    "OwogICQoInQtZ2VuIikuY2xhc3NMaXN0LnRvZ2dsZSgiaGlkZSIsYi5kYXRhc2V0LnQhPT0iZ2VuIik7JCgidC12b3giKS5jbGFz"
    "c0xpc3QudG9nZ2xlKCJoaWRlIixiLmRhdGFzZXQudCE9PSJ2b3giKTsKfSk7CmlmKCQoImJhc2UiKS52YWx1ZSljb25uZWN0KCk7"
    "Cjwvc2NyaXB0Pgo8L2JvZHk+CjwvaHRtbD4K"
)
os.makedirs(LIB_DIR, exist_ok=True)
with open(f"{LIB_DIR}/index_v2.html", "wb") as _f:
    _f.write(base64.b64decode(_INDEX_B64))
print("✅ index_v2.html তৈরি হয়েছে:", f"{LIB_DIR}/index_v2.html", "— Drive-এ হাতে রাখার আর দরকার নেই")


# ══════ নোটবুক সেল 21 ══════
#@title লাইভ সার্ভার চালু করুন (FastAPI + Cloudflare টানেল)
import os, time, subprocess
FAST_MODE = True  #@param {type:"boolean"}
USE_TUNNEL = os.environ.get("USE_TUNNEL", "1") != "0"  #@param {type:"boolean"}
# Cloudflare টানেল শুধু বাইরে থেকে লিংকে ঢুকতে লাগে; বন্ধ করলে সার্ভার http://localhost:8000-এ চলবে
CF_BIN = globals().get("CF_BIN") or f"{LIB_DIR}/bin/cloudflared"
if USE_TUNNEL:
    for _ in range(60):  # cloudflared ইনস্টল সেলে ব্যাকগ্রাউন্ডে নামে
        if os.path.exists(CF_BIN) and os.access(CF_BIN, os.X_OK): break
        time.sleep(1)
    else:
        print("cloudflared এখনও নামেনি; টানেল ছাড়াই লোকাল সার্ভার চলবে")
        USE_TUNNEL = False

import threading, subprocess, re, secrets, tempfile, os, json, shutil, urllib.parse, soundfile as sf
import uvicorn
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, FileResponse, JSONResponse, HTMLResponse
from pydantic import BaseModel

TOKEN = os.environ.get("VOICE_TOKEN") or secrets.token_urlsafe(9)
cpu_lock = threading.Lock()
api = FastAPI(title="Any people bd voice clone")

@api.middleware("http")
async def _auth(request: Request, call_next):
    if request.url.path.startswith("/api") and request.method != "OPTIONS":
        if request.headers.get("x-token") != TOKEN:
            return JSONResponse({"detail": "টোকেন ভুল বা নেই"}, status_code=401)
    return await call_next(request)

api.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"], expose_headers=["X-Report"])

def _save_upload(f: UploadFile):
    ext = os.path.splitext(f.filename or "")[1] or ".wav"
    fd, tmp = tempfile.mkstemp(suffix=ext); os.close(fd)
    with open(tmp, "wb") as o: shutil.copyfileobj(f.file, o)
    return tmp

def _b(v): return str(v).lower() in ("1", "true", "yes", "on")

@api.get("/")
def index():
    p = next((q for q in (f"{LIB_DIR}/index_v2.html", f"{LIB_DIR}/index.html") if os.path.exists(q)), "")
    if p:
        html = open(p, encoding="utf-8").read().replace("Bangla Voice Lab", "Any people bd voice clone")
        return HTMLResponse(html)
    return HTMLResponse("<meta charset=utf-8><h3>index.html পাওয়া যায়নি</h3>Drive-এর BanglaVoiceLab ফোল্ডারে index.html রাখুন।")

@api.get("/api/health")
def health():
    return {"ok": True, "gpu": "CPU", "voices": len(list_voices())}

@api.get("/api/voices")
def voices():
    out = []
    for v in list_voices():
        m = json.load(open(f"{LIB_DIR}/voices/{v}/meta.json", encoding="utf-8"))
        out.append({"id": v, "name": m.get("name", v), "ref_text": m.get("ref_text", ""), "quality": m.get("quality", {})})
    return out

@api.post("/api/voices")
def voices_create(file: UploadFile = File(...), name: str = Form(...), ref_text: str = Form(""),
                  consent: str = Form("false"), denoise: str = Form("true"), pick_best: str = Form("true")):
    if not _b(consent): raise HTTPException(400, "সম্মতি (consent) দরকার")
    tmp = _save_upload(file)
    try:
        with cpu_lock:
            vid, meta = create_voice(name, tmp, ref_text, True, _b(denoise), _b(pick_best))
    except Exception as e:
        raise HTTPException(400, str(e))
    finally:
        os.remove(tmp)
    return {"id": vid, "name": meta["name"], "quality": meta["quality"], "ref_text": meta["ref_text"]}

@api.delete("/api/voices/{vid}")
def voices_delete(vid: str):
    delete_voice(vid); return {"ok": True}

@api.get("/api/voices/{vid}/ref")
def voices_ref(vid: str):
    p = f"{LIB_DIR}/voices/{vid}/ref.wav"
    if not os.path.exists(p): raise HTTPException(404, "নেই")
    return FileResponse(p, media_type="audio/wav")

@api.post("/api/transcribe")
def transcribe(file: UploadFile = File(...), denoise: str = Form("true"), pick_best: str = Form("true")):
    tmp = _save_upload(file)
    try:
        with cpu_lock:
            path, rep = prepare_reference(tmp, denoise=_b(denoise), pick_best=_b(pick_best), out_path=f"{WORK_DIR}/_tr.wav")
            text = transcribe_bn(path)
    except Exception as e:
        raise HTTPException(400, str(e))
    finally:
        os.remove(tmp)
    return {"text": text, "quality": rep["notes"]}

PROGRESS = {"pct": 0, "desc": "", "active": False}

@api.get("/api/progress")
def progress_ep():
    return PROGRESS

class TTSReq(BaseModel):
    voice: str
    text: str
    speed: float = 1.0
    steps: int = 16
    guidance: float = 2.0
    best_of: int = 1
    seed: int = -1
    normalize: bool = True
    fmt: str = "wav"
    lexicon: dict = {}

@api.post("/api/tts")
def tts(r: TTSReq):
    if not r.text.strip(): raise HTTPException(400, "টেক্সট খালি")
    if r.voice not in list_voices(): raise HTTPException(404, "ভয়েস পাওয়া যায়নি")
    normalizer.lex.update({k: v for k, v in r.lexicon.items() if k and v})
    steps_ = max(8, min(r.steps, 64)); best_ = max(1, min(r.best_of, 6))
    if FAST_MODE:  # index.html যা-ই পাঠাক, দ্রুত জেনারেশনের জন্য সীমা
        steps_, best_ = min(steps_, 16), 1
    def _prog(frac, desc=""):
        PROGRESS.update(pct=int(max(0.0, min(1.0, float(frac))) * 100), desc=desc, active=True)
    try:
        with cpu_lock:
            PROGRESS.update(pct=0, desc="শুরু", active=True)
            y, rep = synthesize_fast(r.text, r.voice, speed=r.speed, num_step=steps_,
                                guidance_scale=r.guidance, seed=r.seed, best_of=best_, do_normalize=r.normalize,
                                progress=_prog)
    except Exception as e:
        PROGRESS.update(active=False)
        raise HTTPException(500, str(e))
    PROGRESS.update(pct=100, desc="সম্পন্ন", active=False)
    fd, buf = tempfile.mkstemp(suffix=".wav"); os.close(fd); sf.write(buf, y, SR)
    mime = "audio/wav"
    if r.fmt == "mp3":
        mp3 = buf.replace(".wav", ".mp3")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", buf, "-b:a", "192k", mp3], check=True)
        os.remove(buf); buf, mime = mp3, "audio/mpeg"
    data = open(buf, "rb").read(); os.remove(buf)
    return Response(data, media_type=mime, headers={"X-Report": urllib.parse.quote(rep)})

# ───────── রিয়েল-টাইম স্ট্রিমিং (Turbo Engine) ─────────
from fastapi.responses import StreamingResponse
import numpy as np

class TTSStreamReq(TTSReq):
    first_steps: int = 8
    batch_chars: int = 240

@api.post("/api/tts_stream")
def tts_stream(r: TTSStreamReq):
    if not r.text.strip(): raise HTTPException(400, "টেক্সট খালি")
    if r.voice not in list_voices(): raise HTTPException(404, "ভয়েস পাওয়া যায়নি")
    normalizer.lex.update({k: v for k, v in r.lexicon.items() if k and v})
    steps_ = max(4, min(r.steps, 64)); first_ = max(4, min(r.first_steps, 64))
    if FAST_MODE: steps_, first_ = min(steps_, 16), min(first_, 16)
    def gen():
        for a, pause in turbo_stream(r.text, r.voice, speed=r.speed, steps=steps_, first_steps=first_,
                                     guide=r.guidance, seed=r.seed, do_normalize=r.normalize,
                                     batch_chars=max(60, min(r.batch_chars, 600)), lock=cpu_lock):
            yield (np.clip(a, -1, 1) * 32767).astype("<i2").tobytes()
            yield np.zeros(int(SR * pause), dtype="<i2").tobytes()
    return StreamingResponse(gen(), media_type="application/octet-stream",
                             headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})

@api.get("/api/turbo_stats")
def turbo_stats(): return dict(TURBO_LAST)

_LIVE_HTML = r"""<!doctype html><html lang="bn"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Any people bd voice clone — লাইভ</title>
<style>:root{--bg:#0f1420;--card:#171e2e;--line:#27314a;--tx:#e8ecf5;--mut:#8b97b3;--ac:#2dd4a0}
*{box-sizing:border-box}body{font:16px/1.6 "Noto Sans Bengali",system-ui,sans-serif;margin:0;background:radial-gradient(1000px 500px at 10% -10%,#1b2a4a55,transparent),var(--bg);color:var(--tx)}
.w{max-width:820px;margin:auto;padding:16px}h2{margin:6px 0 2px}.sub{color:var(--mut);font-size:14px;margin-bottom:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px;margin-bottom:12px}
label{display:block;color:var(--mut);font-size:13px;margin:8px 0 3px}
input,select,textarea{width:100%;padding:9px 11px;border-radius:10px;border:1px solid var(--line);background:var(--bg);color:inherit;font:inherit}
textarea{min-height:150px;resize:vertical}.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px}
button{border:0;border-radius:10px;padding:10px 18px;font:inherit;font-weight:600;cursor:pointer;color:#04281d;background:linear-gradient(90deg,#2dd4a0,#38bdf8);margin:12px 8px 0 0}
button.s{background:#ff6b6b;color:#fff}button.d{background:transparent;border:1px solid var(--line);color:var(--tx)}button:disabled{opacity:.45;cursor:not-allowed}
canvas{width:100%;height:70px;display:block;border-radius:10px;background:var(--bg)}
.st{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin-top:10px}.st div{background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:6px 10px;font-size:13px;color:var(--mut)}
.st b{display:block;color:var(--tx);font-size:17px}#m{color:var(--mut);margin-top:8px;white-space:pre-wrap;font-size:14px}</style></head><body><div class="w">
<h2>🎧 রিয়েল-টাইম ভয়েস</h2><div class="sub">Any people bd voice clone — প্রতিটি বাক্য তৈরি হওয়ামাত্র বাজে</div>
<div class="card"><canvas id="viz"></canvas>
<div class="st"><div>প্রথম শব্দ<b id="s1">—</b></div><div>বাজানো অডিও<b id="s2">—</b></div><div>এগিয়ে আছে (বাফার)<b id="s3">—</b></div><div>অবস্থা<b id="s4">প্রস্তুত</b></div></div></div>
<div class="card"><label>টোকেন</label><input id="tok" type="password">
<label>ভয়েস</label><select id="v"></select>
<label>টেক্সট</label><textarea id="t">আসসালামু আলাইকুম। আজ আবহাওয়া খুব সুন্দর। চলুন একসাথে ঘুরতে যাই। বিকেলে আমরা নদীর ধারে হাঁটব এবং চা খাব।</textarea>
<div class="g"><div><label>গতি</label><input id="sp" type="number" step="0.1" value="1.0"></div>
<div><label>স্টেপ (বাকি বাক্য)</label><input id="st" type="number" value="12"></div>
<div><label>প্রথম বাক্যের স্টেপ</label><input id="fs" type="number" value="8"></div>
<div><label>প্রি-বাফার (সেকেন্ড)</label><input id="pb" type="number" step="0.1" value="0"></div></div>
<button id="go">▶ বলো</button><button class="s" id="stop">■ থামাও</button><button class="d" id="dl" disabled>⬇ WAV সেভ</button><div id="m"></div></div></div>
<script>
const SR=24000,$=i=>document.getElementById(i);let ctx=null,an=null,ab=null,nextT=0,srcs=[],pcm=[],raf=0,t0=0;
const mt=location.hash.match(/token=([^&]+)/);if(mt)$("tok").value=decodeURIComponent(mt[1]);
const H=()=>({"x-token":$("tok").value.trim(),"Content-Type":"application/json"});
const msg=s=>$("m").textContent=s;
async function loadVoices(){try{const r=await fetch("/api/voices",{headers:H()});if(!r.ok)throw 0;
const a=await r.json();$("v").innerHTML=a.map(v=>`<option value="${v.id}">${v.name}</option>`).join("");
if(!a.length)msg("আগে একটি ভয়েস সেভ করুন")}catch(e){msg("ভয়েস লোড হয়নি (টোকেন ঠিক আছে?)")}}
function draw(){if(!an||!ctx)return;const d=new Uint8Array(an.frequencyBinCount);an.getByteFrequencyData(d);
const c=$("viz"),g=c.getContext("2d");c.width=c.clientWidth;c.height=70;g.clearRect(0,0,c.width,c.height);
const n=56,w=c.width/n;for(let i=0;i<n;i++){const v=d[i]/255,h=Math.max(2,v*c.height);g.fillStyle=`hsl(${150+i*3.2},85%,${45+v*20}%)`;g.fillRect(i*w+1,c.height-h,w-3,h)}
$("s3").textContent=Math.max(0,nextT-ctx.currentTime).toFixed(1)+" s";raf=requestAnimationFrame(draw)}
function stop(){if(ab)ab.abort();srcs.forEach(s=>{try{s.stop()}catch(e){}});srcs=[];cancelAnimationFrame(raf);if(ctx){ctx.close();ctx=null}}
function wavBlob(){const n=pcm.reduce((a,b)=>a+b.length,0),buf=new ArrayBuffer(44+n*2),v=new DataView(buf);
const ws=(o,s)=>{for(let i=0;i<s.length;i++)v.setUint8(o+i,s.charCodeAt(i))};
ws(0,"RIFF");v.setUint32(4,36+n*2,true);ws(8,"WAVEfmt ");v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);
v.setUint32(24,SR,true);v.setUint32(28,SR*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);ws(36,"data");v.setUint32(40,n*2,true);
let o=44;for(const p of pcm){for(let i=0;i<p.length;i++){v.setInt16(o,p[i],true);o+=2}}return new Blob([buf],{type:"audio/wav"})}
async function go(){stop();pcm=[];$("dl").disabled=true;$("s1").textContent="—";$("s2").textContent="0.0 s";
ctx=new(window.AudioContext||window.webkitAudioContext)({sampleRate:SR});await ctx.resume();
an=ctx.createAnalyser();an.fftSize=256;an.connect(ctx.destination);draw();
ab=new AbortController();nextT=ctx.currentTime+0.15+(+$("pb").value||0);t0=performance.now();let first=true,rest=new Uint8Array(0),tot=0;
$("s4").textContent="তৈরি হচ্ছে";msg("");
try{const r=await fetch("/api/tts_stream",{method:"POST",headers:H(),signal:ab.signal,body:JSON.stringify({voice:$("v").value,text:$("t").value,speed:+$("sp").value,steps:+$("st").value,first_steps:+$("fs").value})});
if(!r.ok){msg("ত্রুটি: "+(await r.text()));$("s4").textContent="ত্রুটি";return}
const rd=r.body.getReader();
while(true){const{done,value}=await rd.read();if(done)break;
const b=new Uint8Array(rest.length+value.length);b.set(rest);b.set(value,rest.length);
const n=b.length-(b.length%2);rest=b.slice(n);if(!n)continue;
const i16=new Int16Array(b.buffer.slice(0,n)),f=new Float32Array(i16.length);for(let i=0;i<f.length;i++)f[i]=i16[i]/32768;
pcm.push(i16);tot+=i16.length;
const buf=ctx.createBuffer(1,f.length,SR);buf.copyToChannel(f,0);const s=ctx.createBufferSource();s.buffer=buf;s.connect(an);
if(nextT<ctx.currentTime+0.05)nextT=ctx.currentTime+0.05;s.start(nextT);nextT+=buf.duration;srcs.push(s);
if(first){first=false;$("s1").textContent=Math.round(performance.now()-t0)+" ms";$("s4").textContent="বাজছে"}
$("s2").textContent=(tot/SR).toFixed(1)+" s"}
$("s4").textContent="শেষ ✅";$("dl").disabled=!pcm.length}catch(e){if(e.name!=="AbortError"){msg("ত্রুটি: "+e);$("s4").textContent="ত্রুটি"}}}
$("go").onclick=go;$("stop").onclick=()=>{stop();$("s4").textContent="থামানো";msg("")};
$("dl").onclick=()=>{const a=document.createElement("a");a.href=URL.createObjectURL(wavBlob());a.download="voice.wav";a.click()};
$("tok").onchange=loadVoices;loadVoices();
</script></body></html>"""

@api.get("/live")
def live_page():
    return HTMLResponse(_LIVE_HTML)

try:   # আগের সার্ভার থাকলে বন্ধ (পোর্ট দ্বন্দ্ব এড়াতে)
    srv.should_exit = True; time.sleep(1.5)
except NameError:
    pass
srv = uvicorn.Server(uvicorn.Config(api, host=os.environ.get("HOST", "0.0.0.0"), port=int(os.environ.get("PORT", "8000")), log_level="warning"))
threading.Thread(target=srv.run, daemon=True).start()

PUBLIC_URL = None
if USE_TUNNEL:
    try:
        tun = subprocess.Popen([CF_BIN, "tunnel", "--url", f"http://localhost:{os.environ.get('PORT', '8000')}", "--no-autoupdate"],
                               stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, text=True)
        _found = threading.Event()
        def _read_tun():
            global PUBLIC_URL
            for line in tun.stderr:
                m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
                if m and not _found.is_set(): PUBLIC_URL = m.group(0); _found.set()
        threading.Thread(target=_read_tun, daemon=True).start()
        _found.wait(60)
    except Exception as e:
        print("Cloudflare টানেল চালু হয়নি:", e)
if not PUBLIC_URL:
    PUBLIC_URL = os.environ.get("PUBLIC_URL") or f"http://localhost:{os.environ.get('PORT', '8000')}"
    print("⚠️ পাবলিক URL পাওয়া যায়নি; লোকাল ঠিকানা দেখানো হচ্ছে")

print("=" * 60)
print("✅ লাইভ URL :", PUBLIC_URL)
print("🔑 টোকেন    :", TOKEN)
print("👉 এক ক্লিকে খুলুন:", f"{PUBLIC_URL}/#token={TOKEN}")
print("=" * 60)
print("🎧 রিয়েল-টাইম (বলার সাথে সাথে শোনা):", f"{PUBLIC_URL}/live#token={TOKEN}")
print("index.html Drive-এ না থাকলে আলাদাভাবে খুললে উপরের URL ও টোকেন UI-তে বসান।")

if __name__ == "__main__":
    import time as _t
    try:
        while True: _t.sleep(3600)
    except KeyboardInterrupt:
        srv.should_exit = True
