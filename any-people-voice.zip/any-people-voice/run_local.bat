@echo off
REM লোকাল চালানো (Windows): http://localhost:8000
cd /d %~dp0
if not exist .venv ( python -m venv .venv && call .venv\Scripts\activate && pip install -r requirements.txt ) else ( call .venv\Scripts\activate )
set USE_TUNNEL=0
python app.py
