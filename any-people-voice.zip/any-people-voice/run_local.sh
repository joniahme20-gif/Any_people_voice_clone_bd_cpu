#!/usr/bin/env bash
# লোকাল চালানো (Linux/Mac): http://localhost:8000
cd "$(dirname "$0")"
[ -d .venv ] || { python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt; }
. .venv/bin/activate
USE_TUNNEL=0 python app.py
