# Any people bd voice clone (CPU / সার্ভার)

```
any-people-voice/
├── voice_clone_cpu_final.ipynb   # নোটবুক (সব ধাপ, Gradio UI, পরীক্ষা)
├── app.py                        # নোটবুক ছাড়া সার্ভার: python app.py
├── requirements.txt
├── run_local.sh / run_local.bat  # এক ক্লিকে লোকাল চালানো
├── Dockerfile / docker-compose.yml  # ওয়েবসাইট/VPS-এ চালানো
└── README.md
```

## চালানোর নিয়ম
**নোটবুক:** খুলে ওপর থেকে নিচে সেল চালান (প্রথম সেল প্যাকেজ ইনস্টল করে)।

**সার্ভার:**
```
pip install -r requirements.txt
python app.py
```
টার্মিনালে লাইভ URL, টোকেন ও `/live` লিংক আসবে।

পরিবেশ ভ্যারিয়েবল (ঐচ্ছিক): `VOICE_LAB_DIR` (সেভ ফোল্ডার), `USE_TUNNEL=0` (Cloudflare ছাড়া, শুধু `http://localhost:8000`), `VOICE_TOKEN` (রিস্টার্টেও একই টোকেন)।

## স্থায়ী ফাইল (`~/BanglaVoiceLab`)
`models/` (মডেল একবারই নামে), `voices/` (ভয়েস প্রোফাইল), `outputs/`, `uploads/`, `tmp/`। রিস্টার্টের পর এগুলোই আবার ব্যবহার হয়।

## মনে রাখবেন
- নোটবুক ও `app.py` একই সঙ্গে চালাবেন না (মডেল দুইবার RAM নেবে, পোর্ট ৮০০০ এক)। দুটোই একই ফোল্ডার ও ভয়েস ব্যবহার করে।
- LoRA ফাইন-টিউনিং GPU দরকার, তাই CPU-তে বন্ধ (কোড কমেন্টে আছে)।
- শুধু নিজের বা অনুমতিপ্রাপ্ত কণ্ঠ ক্লোন করুন।

## ১) নিজের কম্পিউটারে (localhost)
Python 3.10+ ও ffmpeg ইনস্টল রেখে `run_local.sh` (Windows-এ `run_local.bat`) চালান। প্রথমবার প্যাকেজ ও মডেল নামবে (ইন্টারনেট ও কয়েক GB জায়গা লাগবে), পরে সরাসরি চালু হবে।
তারপর ব্রাউজারে **http://localhost:8000/#token=আপনার_টোকেন** খুলুন (টোকেন টার্মিনালে দেখাবে)। রিয়েল-টাইম পেজ: `/live`।

## ২) ওয়েবসাইট / সার্ভারে (hosting)
**লাগবে:** Docker চালানো যায় এমন VPS বা ক্লাউড VM (Ubuntu), কমপক্ষে ৮ GB RAM ও ৪ CPU কোর (কম হলে খুব ধীর হবে বা মেমরি শেষ হবে)।
> সাধারণ shared hosting / cPanel-এ চলবে না, কারণ সেখানে দীর্ঘক্ষণ চলা Python সার্ভার ও এত RAM দেওয়া হয় না।

```
unzip any-people-voice.zip && cd any-people-voice
# docker-compose.yml-এ VOICE_TOKEN বদলান
docker compose up -d --build
```
সার্ভার `http://সার্ভার-IP:8000`-এ চলবে।

**নিজের ডোমেইন + HTTPS (nginx):**
```
server {
  server_name voice.yourdomain.com;
  client_max_body_size 50m;
  location / {
    proxy_pass http://127.0.0.1:8000;
    proxy_http_version 1.1;
    proxy_buffering off;          # রিয়েল-টাইম অডিওর জন্য জরুরি
    proxy_read_timeout 600s;
  }
}
```
তারপর `certbot --nginx -d voice.yourdomain.com` দিয়ে HTTPS চালু করুন।

**নিরাপত্তা:** `VOICE_TOKEN` অবশ্যই নিজের গোপন মান দিন; এটি ছাড়া কেউ `/api` ব্যবহার করতে পারে না। টোকেন কাউকে দেবেন না।

## ৩) অস্থায়ী লিংক (Cloudflare)
`USE_TUNNEL=1` দিয়ে `python app.py` চালালে সরাসরি পাবলিক `trycloudflare.com` লিংক পাবেন। পরীক্ষার জন্য ভালো, স্থায়ী ওয়েবসাইটের জন্য নয়।

## ঐচ্ছিক ভ্যারিয়েবল
`VOICE_LAB_DIR`, `USE_TUNNEL`, `VOICE_TOKEN`, `PORT` (ডিফল্ট ৮০০০), `HOST` (ডিফল্ট ০.০.০.০)।
